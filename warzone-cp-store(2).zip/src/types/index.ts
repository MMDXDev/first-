export type GameType = 'codm' | 'warzone' | 'both';
export type DeliveryType = 'uid_only' | 'activision_login';
export type OrderStatus = 'pending' | 'processing' | 'delivered' | 'cancelled';
export type TicketStatus = 'open' | 'answered' | 'in_progress' | 'closed';
export type TicketPriority = 'normal' | 'high' | 'urgent';
export type TicketDepartment = 'financial' | 'order_followup' | 'account_issue' | 'general';

export interface CPPackage {
  id: string;
  title: string;
  cpAmount: number;
  bonusCp: number;
  priceToman: number;
  originalPriceToman: number;
  gameType: GameType;
  deliveryType: DeliveryType;
  isPopular?: boolean;
  isFastDelivery?: boolean;
  inStock: boolean;
  description: string;
  image?: string;
  category: string;
}

export interface Order {
  id: string;
  orderCode: string;
  userId: string;
  userName: string;
  packageId: string;
  packageName: string;
  cpAmount: number;
  priceToman: number;
  gameType: GameType;
  deliveryType: DeliveryType;
  playerUid: string;
  playerTag?: string;
  activisionEmail?: string;
  region: string;
  status: OrderStatus;
  createdAt: string;
  deliverySpeedMinutes: number;
  notes?: string;
}

export interface TicketMessage {
  id: string;
  sender: 'user' | 'admin';
  senderName: string;
  message: string;
  timestamp: string;
  isStaff: boolean;
}

export interface Ticket {
  id: string;
  ticketNumber: string;
  userId: string;
  userName: string;
  department: TicketDepartment;
  priority: TicketPriority;
  status: TicketStatus;
  subject: string;
  orderCodeRef?: string;
  createdAt: string;
  updatedAt: string;
  messages: TicketMessage[];
}

export interface SavedAccount {
  id: string;
  gameType: GameType;
  accountName: string;
  playerUid: string;
  region: string;
  isDefault: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  playerUid: string;
  activisionId: string;
  walletBalance: number;
  totalOrders: number;
  securityLevel: string;
  twoFactorEnabled: boolean;
  createdAt: string;
  role: 'member' | 'admin';
}

export interface SecurityAuditLog {
  id: string;
  action: string;
  table: string;
  latencyMs: number;
  ip: string;
  encryption: string;
  status: 'SUCCESS' | 'ENCRYPTED' | 'VERIFIED';
  timestamp: string;
}
