import React, { useEffect, useRef, useState } from 'react';
import { useApp } from '../context/AppContext.tsx';

interface Props {
  children: React.ReactNode;
}

export const HeavySmoothScroll: React.FC<Props> = ({ children }) => {
  const { heavySmoothScroll, setHeavySmoothScroll, activeTab, selectedPackageForBuy, language, t } = useApp();
  const contentRef = useRef<HTMLDivElement>(null);
  const [scrollProgress, setScrollProgress] = useState(0);

  const currentScrollY = useRef(0);
  const targetScrollY = useRef(0);
  const animFrameId = useRef<number | null>(null);

  // Reset scroll to top smoothly when switching tabs
  useEffect(() => {
    targetScrollY.current = 0;
    currentScrollY.current = 0;
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
    setScrollProgress(0);
  }, [activeTab]);

  useEffect(() => {
    const isTouch = window.matchMedia('(pointer: coarse)').matches;
    if (!heavySmoothScroll || isTouch) {
      document.body.style.height = 'auto';
      if (contentRef.current) {
        contentRef.current.style.transform = 'none';
        contentRef.current.style.position = 'static';
      }
      return;
    }

    const updateBodyHeight = () => {
      if (contentRef.current) {
        const height = contentRef.current.getBoundingClientRect().height;
        document.body.style.height = `${Math.ceil(height)}px`;
      }
    };

    updateBodyHeight();
    const resizeObserver = new ResizeObserver(() => updateBodyHeight());
    if (contentRef.current) resizeObserver.observe(contentRef.current);

    // Initial position
    targetScrollY.current = window.scrollY;
    currentScrollY.current = window.scrollY;

    const handleWheel = (e: WheelEvent) => {
      // If modal is open or scrolling inside an inner scrollable box, do not intercept
      if (selectedPackageForBuy) return;
      const target = e.target as HTMLElement | null;
      if (target && target.closest('[data-scroll-lock="true"], .overflow-y-auto, textarea, select')) {
        return;
      }

      e.preventDefault();
      const contentHeight = contentRef.current?.getBoundingClientRect().height || window.innerHeight;
      const maxScroll = Math.max(0, contentHeight - window.innerHeight);

      // Heavy inertia step
      targetScrollY.current = Math.min(Math.max(0, targetScrollY.current + e.deltaY * 1.1), maxScroll);
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (selectedPackageForBuy) return;
      const contentHeight = contentRef.current?.getBoundingClientRect().height || window.innerHeight;
      const maxScroll = Math.max(0, contentHeight - window.innerHeight);

      if (e.key === 'ArrowDown') {
        targetScrollY.current = Math.min(targetScrollY.current + 100, maxScroll);
      } else if (e.key === 'ArrowUp') {
        targetScrollY.current = Math.max(targetScrollY.current - 100, 0);
      } else if (e.key === 'PageDown' || (e.key === ' ' && !e.shiftKey)) {
        targetScrollY.current = Math.min(targetScrollY.current + window.innerHeight * 0.75, maxScroll);
      } else if (e.key === 'PageUp' || (e.key === ' ' && e.shiftKey)) {
        targetScrollY.current = Math.max(targetScrollY.current - window.innerHeight * 0.75, 0);
      } else if (e.key === 'Home') {
        targetScrollY.current = 0;
      } else if (e.key === 'End') {
        targetScrollY.current = maxScroll;
      }
    };

    window.addEventListener('wheel', handleWheel, { passive: false });
    window.addEventListener('keydown', handleKeyDown);

    // Heavy inertia physics loop: lerp with 0.085 damping for heavy mechanical glide feel
    const lerpFactor = 0.085;

    const updateScroll = () => {
      const diff = targetScrollY.current - currentScrollY.current;
      currentScrollY.current += diff * lerpFactor;

      if (contentRef.current) {
        contentRef.current.style.transform = `translate3d(0, -${currentScrollY.current}px, 0)`;
      }

      const contentHeight = contentRef.current?.getBoundingClientRect().height || window.innerHeight;
      const maxScroll = Math.max(0, contentHeight - window.innerHeight);
      const progress = maxScroll > 0 ? (currentScrollY.current / maxScroll) * 100 : 0;
      setScrollProgress(Math.min(100, Math.max(0, progress)));

      animFrameId.current = requestAnimationFrame(updateScroll);
    };

    animFrameId.current = requestAnimationFrame(updateScroll);

    return () => {
      window.removeEventListener('wheel', handleWheel);
      window.removeEventListener('keydown', handleKeyDown);
      resizeObserver.disconnect();
      document.body.style.height = 'auto';
      if (animFrameId.current) cancelAnimationFrame(animFrameId.current);
    };
  }, [heavySmoothScroll, selectedPackageForBuy, activeTab]);

  return (
    <>
      {/* Heavy Smooth Scroll Content Wrapper */}
      <div
        ref={contentRef}
        className={heavySmoothScroll ? 'fixed top-0 left-0 w-full will-change-transform z-10' : 'relative z-10'}
      >
        {children}
      </div>

      {/* Tactical Scroll HUD Progress Track - Position adjusted by language */}
      <div className={`fixed ${language === 'fa' ? 'left-2' : 'right-2'} top-1/2 -translate-y-1/2 z-50 hidden lg:flex flex-col items-center gap-2 pointer-events-none select-none`}>
        <span className="text-[9px] font-mono text-[#00d9b5] rotate-90 origin-center mb-3">
          DEPTH: {Math.round(scrollProgress)}%
        </span>
        <div className="w-1 h-32 bg-[#0b1016] border border-slate-800 rounded-full relative overflow-hidden">
          <div
            className="w-full bg-[#00d9b5] transition-all duration-75 rounded-full"
            style={{ height: `${scrollProgress}%` }}
          />
        </div>
      </div>

      {/* Floating Tactical Scroll Controller Toggle */}
      <div className={`fixed bottom-4 ${language === 'fa' ? 'left-4' : 'right-4'} z-40 hidden sm:block`}>
        <button
          onClick={() => setHeavySmoothScroll(!heavySmoothScroll)}
          className={`flex items-center gap-2 px-3 py-1.5 text-xs font-mono font-medium rounded-lg border transition-all duration-150 backdrop-blur-md ${
            heavySmoothScroll
              ? 'bg-[#080d12]/95 border-[#00d9b5]/40 text-[#00d9b5]'
              : 'bg-[#080d12]/80 border-slate-800 text-slate-400 hover:text-slate-200'
          }`}
          title={language === 'fa' ? 'تغییر حالت اسکرول سنگین فیزیکی' : 'Toggle Mechanical Heavy Scroll'}
        >
          <span className={`w-1.5 h-1.5 rounded-full ${heavySmoothScroll ? 'bg-[#00d9b5]' : 'bg-slate-600'}`} />
          <span>{heavySmoothScroll ? t.scrollHeavy : t.scrollNormal}</span>
        </button>
      </div>
    </>
  );
};
