import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { InteractiveTilt } from './InteractiveTilt.tsx';
import { 
  Search, 
  ArrowUpDown, 
  Zap, 
  Check, 
  Clock, 
  Smartphone, 
  Monitor, 
  ShieldCheck,
  Filter
} from 'lucide-react';

type SortOption = 'cheapest' | 'expensive' | 'most_cp' | 'popular' | 'fast';
type CategoryFilter = 'all' | 'codm' | 'warzone' | 'uid_only' | 'activision_login' | 'battle_pass';

export const StoreView: React.FC = () => {
  const { packages, setSelectedPackageForBuy, language, t } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSort, setSelectedSort] = useState<SortOption>('popular');
  const [selectedCategory, setSelectedCategory] = useState<CategoryFilter>('all');

  const filteredPackages = useMemo(() => {
    let result = [...packages];

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        p => p.title.toLowerCase().includes(q) || 
             p.cpAmount.toString().includes(q) || 
             p.description.toLowerCase().includes(q)
      );
    }

    if (selectedCategory !== 'all') {
      if (selectedCategory === 'codm') {
        result = result.filter(p => p.gameType === 'codm' || p.gameType === 'both');
      } else if (selectedCategory === 'warzone') {
        result = result.filter(p => p.gameType === 'warzone' || p.gameType === 'both');
      } else if (selectedCategory === 'uid_only') {
        result = result.filter(p => p.deliveryType === 'uid_only');
      } else if (selectedCategory === 'activision_login') {
        result = result.filter(p => p.deliveryType === 'activision_login');
      } else if (selectedCategory === 'battle_pass') {
        result = result.filter(p => p.category.includes('battle_pass') || p.category.includes('special'));
      }
    }

    result.sort((a, b) => {
      if (selectedSort === 'cheapest') return a.priceToman - b.priceToman;
      if (selectedSort === 'expensive') return b.priceToman - a.priceToman;
      if (selectedSort === 'most_cp') return (b.cpAmount + b.bonusCp) - (a.cpAmount + a.bonusCp);
      if (selectedSort === 'popular') return (b.isPopular ? 1 : 0) - (a.isPopular ? 1 : 0);
      if (selectedSort === 'fast') return (b.isFastDelivery ? 1 : 0) - (a.isFastDelivery ? 1 : 0);
      return 0;
    });

    return result;
  }, [packages, searchQuery, selectedSort, selectedCategory]);

  const formatPrice = (priceToman: number) => {
    if (language === 'fa') {
      return `${priceToman.toLocaleString('fa-IR')} ${t.currency}`;
    }
    const approxUsd = (priceToman / 50000).toFixed(2);
    return `$${approxUsd} USD`;
  };

  return (
    <div className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 pb-24 ${
      language === 'fa' ? 'text-right' : 'text-left'
    }`}>
      {/* Header section */}
      <div className="mb-8">
        <div className="flex items-center gap-2 text-xs font-mono text-[#00d9b5] mb-2">
          <span>{t.storeHeader}</span>
          <span aria-hidden="true">·</span>
          <span>{t.storeGuarantee}</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white">
          {t.storeTitle}
        </h1>
        <p className="text-sm text-slate-400 mt-1 max-w-2xl leading-relaxed">
          {t.storeSubtitle}
        </p>
      </div>

      {/* Control Bar: Search & Filters with 3D Depth */}
      <InteractiveTilt maxTilt={2.8} scale={1.012} elevationZ={10}>
        <div className="bg-[#0b1016] border border-[#16222f] rounded-2xl p-4 sm:p-5 mb-8 space-y-4 shadow-lg">
          {/* Row 1: Search & Sort Buttons */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
            <div className="relative flex-1">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t.storeSearchPlaceholder}
                className={`w-full bg-[#070b0f] border border-[#192736] focus:border-[#00d9b5] rounded-xl py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none transition-colors ${
                  language === 'fa' ? 'pr-10 pl-4' : 'pl-10 pr-4'
                }`}
              />
              <Search className={`w-4 h-4 text-slate-500 absolute top-1/2 -translate-y-1/2 pointer-events-none ${
                language === 'fa' ? 'right-3.5' : 'left-3.5'
              }`} />
            </div>

            {/* Sort Selector Buttons */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
              <div className="flex items-center gap-1 text-xs text-slate-400 shrink-0">
                <ArrowUpDown className="w-3.5 h-3.5 text-[#00d9b5]" />
                <span>{t.storeSortLabel}</span>
              </div>

              <div className="flex items-center gap-1.5 p-1 bg-[#070b0f] border border-[#192736] rounded-xl shrink-0">
                <button
                  onClick={() => setSelectedSort('popular')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                    selectedSort === 'popular'
                      ? 'bg-[#00d9b5] text-[#06080b]'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {t.storeSortPopular}
                </button>

                <button
                  onClick={() => setSelectedSort('cheapest')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                    selectedSort === 'cheapest'
                      ? 'bg-[#00d9b5] text-[#06080b]'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {t.storeSortCheapest}
                </button>

                <button
                  onClick={() => setSelectedSort('most_cp')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                    selectedSort === 'most_cp'
                      ? 'bg-[#00d9b5] text-[#06080b]'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {t.storeSortMostCp}
                </button>

                <button
                  onClick={() => setSelectedSort('fast')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                    selectedSort === 'fast'
                      ? 'bg-[#00d9b5] text-[#06080b]'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {t.storeSortFast}
                </button>
              </div>
            </div>
          </div>

          {/* Row 2: Category Filter Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pt-2 border-t border-[#131d27]">
            <div className="flex items-center gap-1 text-xs text-slate-500 shrink-0">
              <Filter className="w-3.5 h-3.5 text-[#00d9b5]" />
              <span>{t.storeFilterLabel}</span>
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`px-3 py-1 text-xs font-medium rounded-lg border transition-all whitespace-nowrap shrink-0 ${
                  selectedCategory === 'all'
                    ? 'bg-[#00d9b5]/15 border-[#00d9b5] text-[#00d9b5]'
                    : 'bg-[#070b0f] border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {t.storeFilterAll} ({packages.length})
              </button>

              <button
                onClick={() => setSelectedCategory('codm')}
                className={`px-3 py-1 text-xs font-medium rounded-lg border transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                  selectedCategory === 'codm'
                    ? 'bg-[#00d9b5]/15 border-[#00d9b5] text-[#00d9b5]'
                    : 'bg-[#070b0f] border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>{t.storeFilterCodm}</span>
              </button>

              <button
                onClick={() => setSelectedCategory('warzone')}
                className={`px-3 py-1 text-xs font-medium rounded-lg border transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                  selectedCategory === 'warzone'
                    ? 'bg-[#00d9b5]/15 border-[#00d9b5] text-[#00d9b5]'
                    : 'bg-[#070b0f] border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <Monitor className="w-3.5 h-3.5" />
                <span>{t.storeFilterWarzone}</span>
              </button>

              <button
                onClick={() => setSelectedCategory('uid_only')}
                className={`px-3 py-1 text-xs font-medium rounded-lg border transition-all whitespace-nowrap shrink-0 ${
                  selectedCategory === 'uid_only'
                    ? 'bg-[#00d9b5]/15 border-[#00d9b5] text-[#00d9b5]'
                    : 'bg-[#070b0f] border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {t.storeFilterUid}
              </button>

              <button
                onClick={() => setSelectedCategory('activision_login')}
                className={`px-3 py-1 text-xs font-medium rounded-lg border transition-all whitespace-nowrap shrink-0 ${
                  selectedCategory === 'activision_login'
                    ? 'bg-[#00d9b5]/15 border-[#00d9b5] text-[#00d9b5]'
                    : 'bg-[#070b0f] border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {t.storeFilterActivision}
              </button>

              <button
                onClick={() => setSelectedCategory('battle_pass')}
                className={`px-3 py-1 text-xs font-medium rounded-lg border transition-all whitespace-nowrap shrink-0 ${
                  selectedCategory === 'battle_pass'
                    ? 'bg-[#00d9b5]/15 border-[#00d9b5] text-[#00d9b5]'
                    : 'bg-[#070b0f] border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {t.storeFilterBp}
              </button>
            </div>
          </div>
        </div>
      </InteractiveTilt>

      {/* Package Results Count */}
      <div className="flex items-center justify-between text-xs text-slate-400 mb-6">
        <span>
          {language === 'fa' 
            ? `نمایش ${filteredPackages.length.toLocaleString('fa-IR')} ${t.storeActiveCount}`
            : `Showing ${filteredPackages.length} ${t.storeActiveCount}`}
        </span>
        <span className="font-mono text-[#00d9b5]">{t.storeStockStatus}</span>
      </div>

      {/* Packages Grid with Gentle Mouse Responsive Interaction */}
      {filteredPackages.length === 0 ? (
        <div className="text-center py-16 bg-[#0b1016] border border-[#16222f] rounded-2xl p-8">
          <p className="text-slate-400 text-base mb-4">{t.storeNoResults}</p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('all');
            }}
            className="px-4 py-2 bg-[#00d9b5] text-black font-bold text-xs rounded-xl"
          >
            {t.storeClearFilter}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredPackages.map((pkg) => (
            <InteractiveTilt key={pkg.id} maxTilt={5.0} scale={1.025} elevationZ={18}>
              <div className="bg-[#0b1016] border border-[#16222f] hover:border-[#00d9b5]/40 rounded-2xl p-5 flex flex-col justify-between transition-all h-full group shadow-md">
                <div>
                  {/* Thumbnail */}
                  <div className="w-full h-44 rounded-xl overflow-hidden bg-[#070a0e] mb-4 relative">
                    <img
                      src={pkg.image || '/src/assets/images/cp_points_vault_1792428987465.jpg'}
                      alt={pkg.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
                    />
                    <div className={`absolute top-2.5 ${language === 'fa' ? 'right-2.5' : 'left-2.5'} bg-[#06090e]/85 backdrop-blur-md border border-slate-700 text-[#00d9b5] text-[10px] font-mono px-2 py-0.5 rounded font-bold`}>
                      {pkg.bonusCp > 0 
                        ? `+${language === 'fa' ? pkg.bonusCp.toLocaleString('fa-IR') : pkg.bonusCp} ${t.featuredBonusBadge}` 
                        : t.featuredFastBadge}
                    </div>

                    {pkg.isPopular && (
                      <div className={`absolute bottom-2.5 ${language === 'fa' ? 'right-2.5' : 'left-2.5'} bg-[#00d9b5] text-[#06080b] text-[10px] font-bold px-2 py-0.5 rounded`}>
                        {t.featuredPopularBadge}
                      </div>
                    )}
                  </div>

                  {/* Metadata */}
                  <div className="flex items-center gap-2 text-[11px] text-slate-400 mb-2 font-num">
                    <span>
                      {pkg.gameType === 'codm' 
                        ? (language === 'fa' ? 'کالاف دیوتی موبایل' : 'COD Mobile') 
                        : pkg.gameType === 'warzone' 
                        ? (language === 'fa' ? 'وارزون' : 'Warzone') 
                        : (language === 'fa' ? 'موبایل و وارزون' : 'Warzone & Mobile')}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>
                      {pkg.deliveryType === 'uid_only' 
                        ? (language === 'fa' ? 'با آیدی عددی (UID)' : 'Player UID Only') 
                        : (language === 'fa' ? 'با اکانت اکتیویژن' : 'Activision Login')}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-base font-bold text-white mb-2 group-hover:text-[#00d9b5] transition-colors leading-snug">
                    {language === 'fa' 
                      ? pkg.title 
                      : `${pkg.cpAmount.toLocaleString('en-US')} CP Bundle`}
                  </h3>

                  {/* Short specs list */}
                  <div className="space-y-1.5 my-3 text-xs text-slate-300">
                    <div className="flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5 text-[#00d9b5] shrink-0" />
                      <span>
                        {language === 'fa' 
                          ? `حجم کل: ${(pkg.cpAmount + pkg.bonusCp).toLocaleString('fa-IR')} ${t.storeSpec1}`
                          : `Total: ${(pkg.cpAmount + pkg.bonusCp).toLocaleString('en-US')} ${t.storeSpec1}`}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-[#00d9b5] shrink-0" />
                      <span>{t.storeSpec2}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-[#00d9b5] shrink-0" />
                      <span>{t.storeSpec3}</span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-400 leading-relaxed mb-4 line-clamp-2">
                    {language === 'fa' 
                      ? pkg.description 
                      : 'Authentic Activision server injection with encrypted order logging.'}
                  </p>
                </div>

                {/* Price and CTA */}
                <div className="pt-4 border-t border-[#141e2a] flex items-center justify-between">
                  <div>
                    {pkg.originalPriceToman > pkg.priceToman && (
                      <span className="block text-[11px] text-slate-500 line-through font-num">
                        {formatPrice(pkg.originalPriceToman)}
                      </span>
                    )}
                    <div className="text-base font-extrabold text-[#00d9b5] font-num">
                      {formatPrice(pkg.priceToman)}
                    </div>
                  </div>

                  <button
                    onClick={() => setSelectedPackageForBuy(pkg)}
                    className="px-4 py-2.5 bg-[#00d9b5] hover:bg-[#00c49f] text-[#06080b] font-bold text-xs rounded-xl transition-all shadow-sm flex items-center gap-1.5"
                  >
                    <Zap className="w-3.5 h-3.5 fill-current" />
                    <span>{t.featuredBuyNow}</span>
                  </button>
                </div>
              </div>
            </InteractiveTilt>
          ))}
        </div>
      )}
    </div>
  );
};
