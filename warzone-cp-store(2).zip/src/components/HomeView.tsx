import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { InteractiveTilt } from './InteractiveTilt.tsx';
import { useMouseParallax } from '../hooks/useMouseParallax.ts';
import { 
  Zap, 
  ShieldCheck, 
  Clock, 
  Headphones, 
  ArrowLeft, 
  ArrowRight,
  Database,
  Lock,
  Crosshair
} from 'lucide-react';

export const HomeView: React.FC = () => {
  const { packages, setSelectedPackageForBuy, setActiveTab, language, t } = useApp();

  // Quick calculator state
  const [calcCpAmount, setCalcCpAmount] = useState<number>(880);
  const [calcUid, setCalcUid] = useState<string>('');

  // Calm, stabilized mouse parallax coordinates (no jitter)
  const heroParallax = useMouseParallax(2.5);

  const popularPackages = packages.filter(p => p.isPopular).slice(0, 4);

  const getCalcPrice = (cp: number) => {
    const pkg = packages.find(p => p.cpAmount === cp);
    if (pkg) return pkg.priceToman;
    return Math.round(cp * 560);
  };

  const handleQuickCalcBuy = () => {
    const matchedPkg = packages.find(p => p.cpAmount === calcCpAmount) || packages[2];
    setSelectedPackageForBuy(matchedPkg);
  };

  const formatPrice = (priceToman: number) => {
    if (language === 'fa') {
      return `${priceToman.toLocaleString('fa-IR')} ${t.currency}`;
    }
    const approxUsd = (priceToman / 50000).toFixed(2);
    return `$${approxUsd} USD`;
  };

  const ArrowIcon = language === 'fa' ? ArrowLeft : ArrowRight;

  return (
    <div className="relative w-full pb-20">
      {/* SECTION 1: HERO VIEWPORT */}
      <section className="relative pt-8 pb-16 md:py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Main Hero Column */}
          <div 
            className={`lg:col-span-7 space-y-6 transition-transform duration-300 ease-out ${
              language === 'fa' ? 'text-right' : 'text-left'
            }`}
            style={{
              transform: `translate3d(${heroParallax.x * 0.4}px, ${heroParallax.y * 0.4}px, 0)`,
            }}
          >
            {/* Clean Kick-off Metadata */}
            <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
              <span className="text-[#00d9b5] font-bold">{t.heroSector}</span>
              <span aria-hidden="true">·</span>
              <span>{t.heroTag}</span>
              <span aria-hidden="true">·</span>
              <span className="text-slate-300 font-num">{t.heroVersion}</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight leading-tight">
              {t.heroTitlePrefix}{' '}
              <span className="text-[#00d9b5]">{t.heroTitleHighlight}</span>{' '}
              {t.heroTitleSuffix}
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
              {t.heroSubtitle}
            </p>

            {/* Primary Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={() => setActiveTab('store')}
                className="px-6 py-3.5 bg-[#00d9b5] hover:bg-[#00c49f] text-[#06080b] font-extrabold text-sm rounded-xl transition-all shadow-sm flex items-center gap-2.5"
              >
                <span>{t.heroBtnStore}</span>
                <ArrowIcon className="w-4 h-4" />
              </button>

              <button
                onClick={() => setActiveTab('tickets')}
                className="px-5 py-3.5 bg-[#0d151f] hover:bg-[#13202e] text-slate-200 border border-[#1a2938] hover:border-[#00d9b5]/40 font-semibold text-sm rounded-xl transition-all flex items-center gap-2"
              >
                <Headphones className="w-4 h-4 text-[#00d9b5]" />
                <span>{t.heroBtnTickets}</span>
              </button>
            </div>

            {/* Trust Markers Bar */}
            <div className="pt-6 border-t border-[#141e2a] grid grid-cols-3 gap-4 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#00d9b5] shrink-0" />
                <span>{t.heroTrust1}</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#00d9b5] shrink-0" />
                <span>{t.heroTrust2}</span>
              </div>
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-[#00d9b5] shrink-0" />
                <span>{t.heroTrust3}</span>
              </div>
            </div>
          </div>

          {/* Visual Tactical Frame with Noticeable 3D Depth */}
          <div className="lg:col-span-5 relative">
            <InteractiveTilt maxTilt={5.0} scale={1.025} elevationZ={20}>
              <div className="relative rounded-2xl overflow-hidden border border-[#162534] bg-[#090e15] group shadow-lg">
                <img
                  src="/src/assets/images/hero_warzone_tactical_1792428985424.jpg"
                  alt="Warzone Operator"
                  referrerPolicy="no-referrer"
                  className="w-full h-80 sm:h-96 object-cover object-center transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#06090e] via-transparent to-black/30 pointer-events-none" />

                {/* Subtle Floating Tactical HUD Overlay */}
                <div 
                  className={`absolute top-4 ${language === 'fa' ? 'right-4' : 'left-4'} bg-[#06090e]/85 border border-slate-700 rounded-lg px-2.5 py-1 text-[11px] font-mono text-[#00d9b5] backdrop-blur-sm flex items-center gap-1.5 transition-transform duration-200`}
                  style={{
                    transform: `translate3d(${heroParallax.x * 0.3}px, ${heroParallax.y * 0.3}px, 0)`,
                  }}
                >
                  <Crosshair className="w-3 h-3 text-[#00d9b5]" />
                  <span>{t.heroHudBadge}</span>
                </div>

                <div 
                  className="absolute bottom-4 right-4 left-4 bg-[#0a0f16]/95 border border-slate-800 rounded-xl p-3 backdrop-blur-md flex items-center justify-between transition-transform duration-200"
                  style={{
                    transform: `translate3d(${heroParallax.x * -0.2}px, ${heroParallax.y * -0.2}px, 0)`,
                  }}
                >
                  <div className={language === 'fa' ? 'text-right' : 'text-left'}>
                    <div className="text-[10px] text-slate-400 font-mono">{t.heroHudDispatch}</div>
                    <div className="text-xs font-bold text-white">{t.heroHudDesc}</div>
                  </div>
                  <div className="font-mono text-xs text-[#00d9b5] font-bold">
                    {t.heroHudSuccess}
                  </div>
                </div>
              </div>
            </InteractiveTilt>
          </div>

        </div>
      </section>

      {/* SECTION 2: QUICK CALCULATOR WIDGET WITH 3D DEPTH */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <InteractiveTilt maxTilt={3.5} scale={1.015} elevationZ={14}>
          <div className="bg-[#0b1017] border border-[#16222f] rounded-2xl p-6 sm:p-8 relative overflow-hidden shadow-lg">
            <div className="max-w-3xl mx-auto text-center space-y-6">
              <div>
                <span className="text-xs font-mono font-bold tracking-wider text-[#00d9b5] uppercase">
                  {t.calcHeader}
                </span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
                  {t.calcTitle}
                </h2>
                <p className="text-sm text-slate-400 mt-2">
                  {t.calcDesc}
                </p>
              </div>

              {/* CP Selector Buttons */}
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 sm:gap-3">
                {[80, 420, 880, 2400, 5000, 10800].map((amount) => (
                  <button
                    key={amount}
                    onClick={() => setCalcCpAmount(amount)}
                    className={`py-3 px-2 rounded-xl border text-center transition-all ${
                      calcCpAmount === amount
                        ? 'bg-[#00d9b5]/15 border-[#00d9b5] text-[#00d9b5]'
                        : 'bg-[#0e1620] border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <span className="block font-mono font-bold text-sm sm:text-base">
                      {language === 'fa' ? amount.toLocaleString('fa-IR') : amount.toLocaleString('en-US')}
                    </span>
                    <span className="text-[10px] text-slate-400">{t.calcCpUnit}</span>
                  </button>
                ))}
              </div>

              {/* UID and Checkout strip */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-3 pt-2">
                <div className="md:col-span-7">
                  <input
                    type="text"
                    value={calcUid}
                    onChange={(e) => setCalcUid(e.target.value)}
                    placeholder={t.calcUidPlaceholder}
                    className="w-full h-full bg-[#070b10] border border-[#1a2838] focus:border-[#00d9b5] rounded-xl px-4 py-3 text-sm text-white font-mono placeholder:text-slate-600 focus:outline-none"
                  />
                </div>

                <div className="md:col-span-5 flex items-center gap-3">
                  <div className={`flex-1 bg-[#070b10] border border-[#1a2838] rounded-xl px-4 py-2 ${
                    language === 'fa' ? 'text-right' : 'text-left'
                  }`}>
                    <div className="text-[10px] text-slate-400">{t.calcFinalPrice}</div>
                    <div className="text-sm font-extrabold text-[#00d9b5] font-num">
                      {formatPrice(getCalcPrice(calcCpAmount))}
                    </div>
                  </div>

                  <button
                    onClick={handleQuickCalcBuy}
                    className="h-full px-5 py-3 bg-[#00d9b5] hover:bg-[#00c49f] text-[#06080b] font-bold text-sm rounded-xl transition-all whitespace-nowrap flex items-center gap-1.5 shadow-sm"
                  >
                    <Zap className="w-4 h-4 fill-current" />
                    <span>{t.calcSubmitBtn}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </InteractiveTilt>
      </section>

      {/* SECTION 3: FEATURED POPULAR PACKAGES (SUBTLE MOUSE-REACTIVE CARDS) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <div className={language === 'fa' ? 'text-right' : 'text-left'}>
            <span className="text-xs font-mono text-[#00d9b5] font-semibold">{t.featuredHeader}</span>
            <h2 className="text-2xl font-bold text-white mt-1">{t.featuredTitle}</h2>
          </div>

          <button
            onClick={() => setActiveTab('store')}
            className="text-xs font-medium text-[#00d9b5] hover:underline flex items-center gap-1"
          >
            <span>{t.featuredSeeAll}</span>
            <ArrowIcon className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {popularPackages.map((pkg) => (
            <InteractiveTilt key={pkg.id} maxTilt={5.2} scale={1.025} elevationZ={18}>
              <div className="bg-[#0b1016] border border-[#16222f] hover:border-[#00d9b5]/40 rounded-2xl p-5 flex flex-col justify-between transition-all h-full group shadow-md">
                <div>
                  {/* Thumbnail */}
                  <div className="w-full h-40 rounded-xl overflow-hidden bg-[#070a0e] mb-4 relative">
                    <img
                      src={pkg.image || '/src/assets/images/cp_points_vault_1792428987465.jpg'}
                      alt={pkg.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
                    />
                    <div className={`absolute top-2.5 ${language === 'fa' ? 'right-2.5' : 'left-2.5'} bg-[#06090e]/85 backdrop-blur-md border border-slate-700 text-[#00d9b5] text-[10px] font-mono px-2 py-0.5 rounded font-bold`}>
                      +{pkg.bonusCp > 0 
                        ? `${language === 'fa' ? pkg.bonusCp.toLocaleString('fa-IR') : pkg.bonusCp} ${t.featuredBonusBadge}` 
                        : t.featuredFastBadge}
                    </div>

                    {pkg.isPopular && (
                      <div className={`absolute bottom-2.5 ${language === 'fa' ? 'right-2.5' : 'left-2.5'} bg-[#00d9b5] text-[#06080b] text-[10px] font-bold px-2 py-0.5 rounded`}>
                        {t.featuredPopularBadge}
                      </div>
                    )}
                  </div>

                  {/* Metadata */}
                  <div className={`flex items-center gap-2 text-[11px] text-slate-400 mb-1.5 font-num ${
                    language === 'fa' ? 'text-right' : 'text-left'
                  }`}>
                    <span>{pkg.gameType === 'codm' ? (language === 'fa' ? 'کالاف دیوتی موبایل' : 'COD Mobile') : (language === 'fa' ? 'وارزون و موبایل' : 'Warzone & Mobile')}</span>
                    <span aria-hidden="true">·</span>
                    <span>{pkg.deliveryType === 'uid_only' ? (language === 'fa' ? 'با آیدی UID' : 'Player UID') : (language === 'fa' ? 'با اکانت اکتیویژن' : 'Activision Login')}</span>
                  </div>

                  <h3 className={`text-base font-bold text-white mb-2 group-hover:text-[#00d9b5] transition-colors ${
                    language === 'fa' ? 'text-right' : 'text-left'
                  }`}>
                    {language === 'fa' 
                      ? pkg.title 
                      : `${pkg.cpAmount.toLocaleString('en-US')} CP Point Bundle`}
                  </h3>

                  <p className={`text-xs text-slate-400 leading-relaxed line-clamp-2 mb-4 ${
                    language === 'fa' ? 'text-right' : 'text-left'
                  }`}>
                    {language === 'fa'
                      ? pkg.description
                      : `Instant automated legal CP deposit for Call of Duty. Includes bonus CP with zero ban risk.`}
                  </p>
                </div>

                {/* Price & Buy Action */}
                <div className="pt-4 border-t border-[#141e2a] flex items-center justify-between">
                  <div className={language === 'fa' ? 'text-right' : 'text-left'}>
                    {pkg.originalPriceToman > pkg.priceToman && (
                      <span className="block text-[11px] text-slate-500 line-through font-num">
                        {formatPrice(pkg.originalPriceToman)}
                      </span>
                    )}
                    <span className="text-base font-extrabold text-[#00d9b5] font-num">
                      {formatPrice(pkg.priceToman)}
                    </span>
                  </div>

                  <button
                    onClick={() => setSelectedPackageForBuy(pkg)}
                    className="px-3.5 py-2 bg-[#00d9b5] hover:bg-[#00c49f] text-[#06080b] font-bold text-xs rounded-xl transition-all flex items-center gap-1 shadow-sm"
                  >
                    <Zap className="w-3.5 h-3.5 fill-current" />
                    <span>{t.featuredBuyNow}</span>
                  </button>
                </div>
              </div>
            </InteractiveTilt>
          ))}
        </div>
      </section>

      {/* SECTION 4: SECURITY & INFRASTRUCTURE GUARANTEE */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className={`grid grid-cols-1 md:grid-cols-3 gap-6 ${language === 'fa' ? 'text-right' : 'text-left'}`}>
          <InteractiveTilt maxTilt={4.5} scale={1.02} elevationZ={14}>
            <div className="h-full bg-[#090d14] border border-[#14202d] hover:border-[#00d9b5]/40 rounded-2xl p-6 flex gap-4 transition-all">
              <div className="w-12 h-12 rounded-xl bg-[#0f1722] border border-[#00d9b5]/30 text-[#00d9b5] flex items-center justify-center shrink-0">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white mb-1">{t.trust1Title}</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {t.trust1Desc}
                </p>
              </div>
            </div>
          </InteractiveTilt>

          <InteractiveTilt maxTilt={4.5} scale={1.02} elevationZ={14}>
            <div className="h-full bg-[#090d14] border border-[#14202d] hover:border-[#00d9b5]/40 rounded-2xl p-6 flex gap-4 transition-all">
              <div className="w-12 h-12 rounded-xl bg-[#0f1722] border border-[#00d9b5]/30 text-[#00d9b5] flex items-center justify-center shrink-0">
                <Lock className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white mb-1">{t.trust2Title}</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {t.trust2Desc}
                </p>
              </div>
            </div>
          </InteractiveTilt>

          <InteractiveTilt maxTilt={4.5} scale={1.02} elevationZ={14}>
            <div className="h-full bg-[#090d14] border border-[#14202d] hover:border-[#00d9b5]/40 rounded-2xl p-6 flex gap-4 transition-all">
              <div className="w-12 h-12 rounded-xl bg-[#0f1722] border border-[#00d9b5]/30 text-[#00d9b5] flex items-center justify-center shrink-0">
                <Headphones className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white mb-1">{t.trust3Title}</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {t.trust3Desc}
                </p>
              </div>
            </div>
          </InteractiveTilt>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 text-xs text-slate-500 border-t border-[#121c27] flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          {t.footerRights}
        </div>
        <div className="flex items-center gap-4">
          <button onClick={() => setActiveTab('tickets')} className="hover:text-slate-300">
            {t.footerSupport}
          </button>
          <span>·</span>
          <button onClick={() => setActiveTab('admin')} className="hover:text-slate-300">
            {t.footerAdmin}
          </button>
          <span>·</span>
          <span className="font-mono text-[#00d9b5]">POSTGRES_VERIFIED</span>
        </div>
      </footer>
    </div>
  );
};
