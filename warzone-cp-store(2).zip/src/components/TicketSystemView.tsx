import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { TicketDepartment, TicketPriority, TicketStatus } from '../types/index.ts';
import { InteractiveTilt } from './InteractiveTilt.tsx';
import { 
  Headphones, 
  Plus, 
  Send, 
  ShieldCheck, 
  User, 
  MessageSquare
} from 'lucide-react';

export const TicketSystemView: React.FC = () => {
  const { 
    tickets, 
    orders, 
    createTicket, 
    addTicketMessage, 
    updateTicketStatus,
    showToast,
    language,
    t 
  } = useApp();

  const [viewRole, setViewRole] = useState<'member' | 'admin'>('member');
  const [activeTicketId, setActiveTicketId] = useState<string>(tickets[0]?.id || '');
  const [showNewTicketModal, setShowNewTicketModal] = useState(false);

  const [subject, setSubject] = useState('');
  const [department, setDepartment] = useState<TicketDepartment>('order_followup');
  const [priority, setPriority] = useState<TicketPriority>('high');
  const [orderCodeRef, setOrderCodeRef] = useState('');
  const [message, setMessage] = useState('');

  const [replyText, setReplyText] = useState('');
  const [adminStatusFilter, setAdminStatusFilter] = useState<string>('all');

  const selectedTicket = tickets.find(t => t.id === activeTicketId) || tickets[0];

  const handleCreateTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !message.trim()) {
      showToast(
        language === 'fa' 
          ? 'لطفا موضوع و متن پیام را کامل پر کنید.' 
          : 'Please enter both the subject and message text.', 
        'warn'
      );
      return;
    }

    const newTicket = createTicket(subject, department, priority, message, orderCodeRef || undefined);
    setActiveTicketId(newTicket.id);
    setShowNewTicketModal(false);
    setSubject('');
    setMessage('');
    setOrderCodeRef('');
  };

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !selectedTicket) return;

    addTicketMessage(selectedTicket.id, replyText, viewRole === 'admin');
    setReplyText('');
  };

  const handleCannedReply = (template: string) => {
    setReplyText(template);
  };

  const filteredTickets = tickets.filter(t => {
    if (viewRole === 'member') return true;
    if (adminStatusFilter === 'all') return true;
    return t.status === adminStatusFilter;
  });

  const getStatusBadge = (status: TicketStatus) => {
    switch (status) {
      case 'open':
        return <span className="text-[11px] font-semibold text-[#00d9b5]">{language === 'fa' ? 'در انتظار پاسخ' : 'Awaiting Reply'}</span>;
      case 'answered':
        return <span className="text-[11px] font-semibold text-emerald-400">{language === 'fa' ? 'پاسخ داده شده' : 'Answered'}</span>;
      case 'in_progress':
        return <span className="text-[11px] font-semibold text-cyan-300">{language === 'fa' ? 'در حال بررسی' : 'In Progress'}</span>;
      case 'closed':
        return <span className="text-[11px] font-semibold text-slate-500">{language === 'fa' ? 'بسته شده' : 'Closed'}</span>;
    }
  };

  const getDepartmentLabel = (dep: TicketDepartment) => {
    switch (dep) {
      case 'financial': return language === 'fa' ? 'بخش مالی و درگاه' : 'Billing & Payment';
      case 'order_followup': return language === 'fa' ? 'پیگیری سفارش سی‌پی' : 'CP Order Tracking';
      case 'account_issue': return language === 'fa' ? 'خطای اکانت و شارژ' : 'Account & UID Issue';
      case 'general': return language === 'fa' ? 'پشتیبانی عمومی' : 'General Inquiries';
    }
  };

  const getPriorityLabel = (p: TicketPriority) => {
    switch (p) {
      case 'urgent': return language === 'fa' ? 'فوری (سی‌پی)' : 'Urgent';
      case 'high': return language === 'fa' ? 'بالا' : 'High';
      case 'normal': return language === 'fa' ? 'عادی' : 'Normal';
    }
  };

  return (
    <div className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 pb-24 ${
      language === 'fa' ? 'text-right' : 'text-left'
    }`}>
      {/* Header and Dual-Side Switcher */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#00d9b5] mb-1">
            <span>{t.ticketHeader}</span>
            <span aria-hidden="true">·</span>
            <span>{t.ticketSubtitle}</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white">
            {t.ticketTitle}
          </h1>
        </div>

        {/* Dual Mode Switcher (Member Side vs Admin Side) */}
        <div className="flex items-center gap-2 bg-[#080d13] border border-[#162534] p-1.5 rounded-xl self-start md:self-auto">
          <button
            onClick={() => setViewRole('member')}
            className={`px-4 py-2 text-xs font-bold rounded-lg transition-all flex items-center gap-2 ${
              viewRole === 'member'
                ? 'bg-[#00d9b5] text-[#06080b]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>{t.ticketMemberSide}</span>
          </button>

          <button
            onClick={() => setViewRole('admin')}
            className={`px-4 py-2 text-xs font-bold rounded-lg transition-all flex items-center gap-2 ${
              viewRole === 'admin'
                ? 'bg-[#00d9b5] text-[#06080b]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>{t.ticketAdminSide}</span>
          </button>
        </div>
      </div>

      {/* Main Ticket Layout: 2 Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Ticket List Column */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#0b1016] border border-[#16222f] rounded-2xl p-4 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-bold text-white flex items-center gap-1.5">
                <MessageSquare className="w-4 h-4 text-[#00d9b5]" />
                <span>{t.ticketActiveList} ({filteredTickets.length})</span>
              </span>

              {viewRole === 'member' && (
                <button
                  onClick={() => setShowNewTicketModal(true)}
                  className="px-3 py-1.5 bg-[#00d9b5] hover:bg-[#00c49f] text-[#06080b] font-bold text-xs rounded-lg transition-all flex items-center gap-1 shadow-sm"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{t.ticketNewBtn}</span>
                </button>
              )}
            </div>

            {/* Admin status filter */}
            {viewRole === 'admin' && (
              <div className="flex gap-1 overflow-x-auto pb-2 mb-3 border-b border-[#131e2b]">
                {['all', 'open', 'in_progress', 'answered', 'closed'].map((st) => (
                  <button
                    key={st}
                    onClick={() => setAdminStatusFilter(st)}
                    className={`px-2 py-1 text-[11px] rounded-lg border whitespace-nowrap ${
                      adminStatusFilter === st
                        ? 'bg-[#00d9b5]/15 border-[#00d9b5] text-[#00d9b5]'
                        : 'bg-[#070b0f] border-slate-800 text-slate-400'
                    }`}
                  >
                    {st === 'all' 
                      ? (language === 'fa' ? 'همه' : 'All') 
                      : st === 'open' 
                      ? (language === 'fa' ? 'جدید' : 'Open') 
                      : st === 'in_progress' 
                      ? (language === 'fa' ? 'درحال بررسی' : 'In Progress') 
                      : st === 'answered' 
                      ? (language === 'fa' ? 'پاسخ داده' : 'Answered') 
                      : (language === 'fa' ? 'بسته' : 'Closed')}
                  </button>
                ))}
              </div>
            )}

            {/* List */}
            <div className="space-y-2.5 max-h-[550px] overflow-y-auto pr-1">
              {filteredTickets.map((tk) => (
                <InteractiveTilt key={tk.id} maxTilt={3.5} scale={1.018} elevationZ={10}>
                  <div
                    onClick={() => setActiveTicketId(tk.id)}
                    className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                      language === 'fa' ? 'text-right' : 'text-left'
                    } ${
                      activeTicketId === tk.id
                        ? 'bg-[#0e1722] border-[#00d9b5]'
                        : 'bg-[#080c12] border-[#14202d] hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-mono font-bold text-[#00d9b5]">
                        {tk.ticketNumber}
                      </span>
                      {getStatusBadge(tk.status)}
                    </div>

                    <h3 className="text-sm font-bold text-white mb-2 line-clamp-1">
                      {tk.subject}
                    </h3>

                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>{getDepartmentLabel(tk.department)}</span>
                      <span className="font-num">{tk.updatedAt}</span>
                    </div>

                    {tk.orderCodeRef && (
                      <div className="mt-2 text-[10px] font-mono text-[#00d9b5]/90">
                        {t.ticketOrderRef} {tk.orderCodeRef}
                      </div>
                    )}
                  </div>
                </InteractiveTilt>
              ))}
            </div>
          </div>
        </div>

        {/* Active Ticket Conversation Column */}
        <div className="lg:col-span-7">
          {selectedTicket ? (
            <div className="bg-[#0b1016] border border-[#16222f] rounded-2xl flex flex-col h-[650px] overflow-hidden shadow-lg">
              
              {/* Conversation Top Header */}
              <div className="p-4 sm:p-5 border-b border-[#16222f] bg-[#070b10] flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-mono font-bold text-[#00d9b5]">
                      {selectedTicket.ticketNumber}
                    </span>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs text-slate-300 font-semibold">{getDepartmentLabel(selectedTicket.department)}</span>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs text-[#00d9b5] font-num">{t.ticketPriorityLabel} {getPriorityLabel(selectedTicket.priority)}</span>
                  </div>
                  <h2 className="text-base font-bold text-white">
                    {selectedTicket.subject}
                  </h2>
                </div>

                {/* Admin Status Dropdown */}
                {viewRole === 'admin' && (
                  <select
                    value={selectedTicket.status}
                    onChange={(e) => updateTicketStatus(selectedTicket.id, e.target.value as TicketStatus)}
                    className="bg-[#0b1219] border border-slate-700 text-xs text-white rounded-lg px-2.5 py-1.5 focus:border-[#00d9b5] outline-none"
                  >
                    <option value="open">{language === 'fa' ? 'در انتظار پاسخ' : 'Awaiting Reply'}</option>
                    <option value="in_progress">{language === 'fa' ? 'در حال بررسی' : 'In Progress'}</option>
                    <option value="answered">{language === 'fa' ? 'پاسخ داده شده' : 'Answered'}</option>
                    <option value="closed">{language === 'fa' ? 'بستن تیکت' : 'Close Ticket'}</option>
                  </select>
                )}
              </div>

              {/* Messages Thread Box */}
              <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
                {selectedTicket.messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex flex-col max-w-[85%] ${
                      msg.sender === 'user' 
                        ? (language === 'fa' ? 'mr-auto items-start' : 'ml-auto items-end') 
                        : (language === 'fa' ? 'ml-auto items-end' : 'mr-auto items-start')
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1 text-[11px] text-slate-400">
                      <span className="font-semibold text-slate-200">{msg.senderName}</span>
                      {msg.isStaff && (
                        <span className="px-1.5 py-0.2 bg-[#00d9b5]/15 text-[#00d9b5] border border-[#00d9b5]/30 rounded text-[9px] font-bold">
                          {language === 'fa' ? 'پشتیبان رسمی' : 'Official Staff'}
                        </span>
                      )}
                      <span className="font-num">{msg.timestamp}</span>
                    </div>

                    <div
                      className={`p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                        msg.isStaff
                          ? 'bg-[#0f1b26] border border-[#00d9b5]/30 text-slate-100 rounded-tr-none'
                          : 'bg-[#080d14] border border-[#18283a] text-slate-200 rounded-tl-none'
                      }`}
                    >
                      {msg.message}
                    </div>
                  </div>
                ))}
              </div>

              {/* Admin Canned Quick Responses */}
              {viewRole === 'admin' && (
                <div className="p-2.5 bg-[#070b10] border-t border-[#141f2c] flex items-center gap-2 overflow-x-auto text-[11px]">
                  <span className="text-slate-400 shrink-0">{t.ticketQuickReply}</span>
                  <button
                    onClick={() => handleCannedReply(
                      language === 'fa'
                        ? 'سلام و درود، سفارش شما با موفقیت از طریق سرور اکتیویژن واریز گردید. لطفا بازی خود را ریستارت کنید.'
                        : 'Greetings, your CP bundle has been successfully dispatched via Activision server. Please restart your game.'
                    )}
                    className="px-2.5 py-1 bg-[#0d1622] hover:bg-[#132030] text-[#00d9b5] rounded-lg border border-slate-800 shrink-0 whitespace-nowrap"
                  >
                    {language === 'fa' ? 'واریز انجام شد' : 'CP Dispatched'}
                  </button>
                  <button
                    onClick={() => handleCannedReply(
                      language === 'fa'
                        ? 'درود، لطفا UID عددی اکانت خود را از بخش پروفایل بازی با دقت کپی و ارسال فرمایید.'
                        : 'Hello, please copy and paste your numeric Player UID directly from your in-game profile.'
                    )}
                    className="px-2.5 py-1 bg-[#0d1622] hover:bg-[#132030] text-[#00d9b5] rounded-lg border border-slate-800 shrink-0 whitespace-nowrap"
                  >
                    {language === 'fa' ? 'درخواست UID مجدد' : 'Request UID'}
                  </button>
                  <button
                    onClick={() => handleCannedReply(
                      language === 'fa'
                        ? 'اطلاعات شما در پایگاه‌داده بررسی شد و اولویت سفارش به حداکثر تغییر یافت.'
                        : 'Your record has been verified in the database, order priority elevated to urgent.'
                    )}
                    className="px-2.5 py-1 bg-[#0d1622] hover:bg-[#132030] text-[#00d9b5] rounded-lg border border-slate-800 shrink-0 whitespace-nowrap"
                  >
                    {language === 'fa' ? 'ارتقای اولویت واریز' : 'Priority Boost'}
                  </button>
                </div>
              )}

              {/* Send Reply Box */}
              <form onSubmit={handleSendReply} className="p-4 bg-[#070b10] border-t border-[#16222f] flex gap-2">
                <input
                  type="text"
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  placeholder={
                    viewRole === 'admin'
                      ? t.ticketReplyPlaceholderAdmin
                      : t.ticketReplyPlaceholderUser
                  }
                  className="flex-1 bg-[#090e15] border border-[#1b2a3c] focus:border-[#00d9b5] rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white placeholder:text-slate-500 focus:outline-none"
                />
                <button
                  type="submit"
                  className="px-4 py-2.5 bg-[#00d9b5] hover:bg-[#00c49f] text-[#06080b] font-bold text-xs sm:text-sm rounded-xl transition-all shadow-sm flex items-center gap-1.5"
                >
                  <Send className={`w-4 h-4 fill-current ${language === 'fa' ? 'rotate-180' : ''}`} />
                  <span>{t.ticketSend}</span>
                </button>
              </form>

            </div>
          ) : (
            <div className="bg-[#0b1016] border border-[#16222f] rounded-2xl p-12 text-center text-slate-400 shadow-lg">
              {t.ticketSelectToView}
            </div>
          )}
        </div>

      </div>

      {/* New Ticket Modal */}
      {showNewTicketModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" data-scroll-lock="true">
          <div className={`w-full max-w-lg bg-[#0b1016] border border-[#1e2e3e] rounded-2xl p-6 sm:p-8 shadow-2xl ${
            language === 'fa' ? 'text-right' : 'text-left'
          }`}>
            <h2 className="text-xl font-bold text-white mb-2">{t.ticketModalTitle}</h2>
            <p className="text-xs text-slate-400 mb-6">
              {t.ticketModalDesc}
            </p>

            <form onSubmit={handleCreateTicket} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-200 mb-1">
                  {t.ticketSubjectLabel} <span className="text-[#00d9b5]">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder={language === 'fa' ? 'مثال: پیگیری سفارش ۸۸۰ سی‌پی یا عدم اتصال به سرور' : 'e.g., CP Dispatch status or UID assistance'}
                  className="w-full bg-[#080d13] border border-[#1b2838] focus:border-[#00d9b5] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-200 mb-1">
                    {t.ticketDeptLabel}
                  </label>
                  <select
                    value={department}
                    onChange={(e) => setDepartment(e.target.value as TicketDepartment)}
                    className="w-full bg-[#080d13] border border-[#1b2838] focus:border-[#00d9b5] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  >
                    <option value="order_followup">{language === 'fa' ? 'پیگیری سفارش سی‌پی' : 'CP Order Tracking'}</option>
                    <option value="financial">{language === 'fa' ? 'بخش مالی و درگاه' : 'Billing & Payment'}</option>
                    <option value="account_issue">{language === 'fa' ? 'خطای شارژ اکانت و UID' : 'Account & UID'}</option>
                    <option value="general">{language === 'fa' ? 'پشتیبانی عمومی و سوالات' : 'General Support'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-200 mb-1">
                    {t.ticketPriorityLabel}
                  </label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as TicketPriority)}
                    className="w-full bg-[#080d13] border border-[#1b2838] focus:border-[#00d9b5] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  >
                    <option value="urgent">{language === 'fa' ? 'فوری (سی‌پی واریز نشده)' : 'Urgent'}</option>
                    <option value="high">{language === 'fa' ? 'بالا' : 'High'}</option>
                    <option value="normal">{language === 'fa' ? 'عادی' : 'Normal'}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-200 mb-1">
                  {t.ticketOrderRefLabel}
                </label>
                <select
                  value={orderCodeRef}
                  onChange={(e) => setOrderCodeRef(e.target.value)}
                  className="w-full bg-[#080d13] border border-[#1b2838] focus:border-[#00d9b5] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                >
                  <option value="">{language === 'fa' ? 'بدون سفارش (سوال عمومی)' : 'No order attached (General)'}</option>
                  {orders.map((o) => (
                    <option key={o.id} value={o.orderCode}>
                      {o.orderCode} — {o.packageName}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-200 mb-1">
                  {t.ticketMessageLabel} <span className="text-[#00d9b5]">*</span>
                </label>
                <textarea
                  required
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder={language === 'fa' ? 'لطفا توضیحات دقیق مشکل، UID یا جزییات را بنویسید...' : 'Please enter specific issue details, UID, or questions...'}
                  className="w-full bg-[#080d13] border border-[#1b2838] focus:border-[#00d9b5] rounded-xl p-3 text-xs sm:text-sm text-white focus:outline-none"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-3 bg-[#00d9b5] hover:bg-[#00c49f] text-[#06080b] font-bold text-xs rounded-xl shadow-sm transition-all"
                >
                  {t.ticketSubmit}
                </button>
                <button
                  type="button"
                  onClick={() => setShowNewTicketModal(false)}
                  className="px-5 py-3 bg-[#111923] text-slate-300 font-medium text-xs rounded-xl border border-slate-700"
                >
                  {t.ticketCancel}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
