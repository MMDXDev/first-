import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { InteractiveTilt } from './InteractiveTilt.tsx';
import { 
  User, 
  Wallet, 
  ShoppingBag, 
  ShieldCheck, 
  Plus, 
  Trash2, 
  Lock, 
  Smartphone, 
  CreditCard,
  Key
} from 'lucide-react';
import { GameType, Order } from '../types/index.ts';

type UCPTab = 'orders' | 'accounts' | 'wallet' | 'security';

export const UCPView: React.FC = () => {
  const { 
    user, 
    orders, 
    savedAccounts, 
    addSavedAccount, 
    deleteSavedAccount, 
    depositWallet, 
    toggleTwoFactor,
    showToast,
    language,
    t
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<UCPTab>('orders');
  const [selectedOrderDetails, setSelectedOrderDetails] = useState<Order | null>(null);

  const [showAddAccountModal, setShowAddAccountModal] = useState(false);
  const [newAccName, setNewAccName] = useState('');
  const [newAccUid, setNewAccUid] = useState('');
  const [newAccType, setNewAccType] = useState<GameType>('codm');
  const [newAccRegion, setNewAccRegion] = useState(language === 'fa' ? 'هند' : 'India');

  const [depositAmount, setDepositAmount] = useState<number>(250000);
  const [giftCardCode, setGiftCardCode] = useState('');

  const formatPrice = (priceToman: number) => {
    if (language === 'fa') {
      return `${priceToman.toLocaleString('fa-IR')} ${t.currency}`;
    }
    const approxUsd = (priceToman / 50000).toFixed(2);
    return `$${approxUsd} USD`;
  };

  const handleAddAccountSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAccName || !newAccUid) {
      showToast(
        language === 'fa' 
          ? 'لطفا نام و UID اکانت را پر نمایید.' 
          : 'Please enter both the account name and Player UID.', 
        'warn'
      );
      return;
    }
    addSavedAccount({
      accountName: newAccName,
      playerUid: newAccUid,
      gameType: newAccType,
      region: newAccRegion,
      isDefault: savedAccounts.length === 0,
    });
    setNewAccName('');
    setNewAccUid('');
    setShowAddAccountModal(false);
  };

  const handleRedeemGift = (e: React.FormEvent) => {
    e.preventDefault();
    if (giftCardCode.trim().toUpperCase() === 'WARZONE2026') {
      depositWallet(100000);
      setGiftCardCode('');
    } else {
      showToast(
        language === 'fa' 
          ? 'کد هدیه نامعتبر است. کد تست: WARZONE2026' 
          : 'Invalid voucher code. Test code: WARZONE2026', 
        'warn'
      );
    }
  };

  const getOrderStatusDisplay = (status: Order['status']) => {
    switch (status) {
      case 'delivered':
        return <span className="text-xs font-bold text-emerald-400">{language === 'fa' ? 'تکمیل و واریز شده' : 'Delivered & Injected'}</span>;
      case 'processing':
        return (
          <span className="text-xs font-bold text-[#00d9b5] flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00d9b5] animate-ping" /> 
            {language === 'fa' ? 'در حال اتصال و شارژ' : 'Dispatching CP'}
          </span>
        );
      case 'pending':
        return <span className="text-xs font-bold text-yellow-400">{language === 'fa' ? 'در صف تایید' : 'Pending Queue'}</span>;
      case 'cancelled':
        return <span className="text-xs font-bold text-slate-500">{language === 'fa' ? 'لغو شده' : 'Cancelled'}</span>;
    }
  };

  return (
    <div className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 pb-24 ${
      language === 'fa' ? 'text-right' : 'text-left'
    }`}>
      {/* Profile Overview Card with 3D Depth */}
      <InteractiveTilt maxTilt={3.6} scale={1.018} elevationZ={16} className="mb-8">
        <div className="bg-[#0b1016] border border-[#16222f] hover:border-[#00d9b5]/40 rounded-2xl p-6 relative overflow-hidden shadow-xl transition-colors">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-[#080d13] border border-[#00d9b5]/40 flex items-center justify-center text-[#00d9b5]">
                <User className="w-8 h-8" />
              </div>

              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h1 className="text-2xl font-extrabold text-white">{user.name}</h1>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#00d9b5]/15 text-[#00d9b5] border border-[#00d9b5]/30 font-bold">
                    {t.ucpVerifiedBadge}
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 font-num">
                  <span>{t.ucpActivisionTag} <strong className="text-slate-200">{user.activisionId}</strong></span>
                  <span aria-hidden="true">·</span>
                  <span>UID: <strong className="text-slate-200 font-mono">{user.playerUid}</strong></span>
                  <span aria-hidden="true">·</span>
                  <span>{t.ucpMemberSince} {user.createdAt}</span>
                </div>
              </div>
            </div>

            {/* Quick Metrics Bar */}
            <div className="flex items-center gap-3 sm:gap-4 w-full md:w-auto justify-between md:justify-end border-t md:border-t-0 pt-4 md:pt-0 border-slate-800">
              <div className="bg-[#070b0f] border border-[#141f2b] rounded-xl px-4 py-2.5 text-center">
                <span className="block text-[11px] text-slate-400">{t.walletBalance}</span>
                <span className="text-base font-extrabold text-[#00d9b5] font-num">
                  {formatPrice(user.walletBalance)}
                </span>
              </div>

              <div className="bg-[#070b0f] border border-[#141f2b] rounded-xl px-4 py-2.5 text-center">
                <span className="block text-[11px] text-slate-400">{t.ucpTotalOrders}</span>
                <span className="text-base font-extrabold text-white font-num">
                  {language === 'fa' ? `${user.totalOrders.toLocaleString('fa-IR')} خرید` : `${user.totalOrders} Orders`}
                </span>
              </div>
            </div>
          </div>
        </div>
      </InteractiveTilt>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-[#14202d] pb-3 mb-8 overflow-x-auto">
        <button
          onClick={() => setActiveSubTab('orders')}
          className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
            activeSubTab === 'orders'
              ? 'bg-[#00d9b5] text-[#06080b]'
              : 'text-slate-400 hover:text-white bg-[#0b1016]'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>{t.ucpTabOrders} ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('accounts')}
          className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
            activeSubTab === 'accounts'
              ? 'bg-[#00d9b5] text-[#06080b]'
              : 'text-slate-400 hover:text-white bg-[#0b1016]'
          }`}
        >
          <Smartphone className="w-4 h-4" />
          <span>{t.ucpTabAccounts} ({savedAccounts.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('wallet')}
          className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
            activeSubTab === 'wallet'
              ? 'bg-[#00d9b5] text-[#06080b]'
              : 'text-slate-400 hover:text-white bg-[#0b1016]'
          }`}
        >
          <Wallet className="w-4 h-4" />
          <span>{t.ucpTabWallet}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('security')}
          className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
            activeSubTab === 'security'
              ? 'bg-[#00d9b5] text-[#06080b]'
              : 'text-slate-400 hover:text-white bg-[#0b1016]'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>{t.ucpTabSecurity}</span>
        </button>
      </div>

      {/* SUB-TAB 1: ORDERS */}
      {activeSubTab === 'orders' && (
        <div className="space-y-4">
          <div className="bg-[#0b1016] border border-[#16222f] rounded-2xl p-6 shadow-md">
            <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#00d9b5]" />
              <span>{t.ucpOrdersTitle}</span>
            </h2>

            <div className="divide-y divide-[#131e2b]">
              {orders.map((ord) => (
                <div
                  key={ord.id}
                  className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-[#0e1724]/30 px-3 rounded-xl transition-colors"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-mono font-bold text-[#00d9b5]">
                        {ord.orderCode}
                      </span>
                      <span className="text-sm font-bold text-white">{ord.packageName}</span>
                      {getOrderStatusDisplay(ord.status)}
                    </div>

                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 font-num">
                      <span>CP: <strong>{language === 'fa' ? ord.cpAmount.toLocaleString('fa-IR') : ord.cpAmount.toLocaleString('en-US')} CP</strong></span>
                      <span aria-hidden="true">·</span>
                      <span>{formatPrice(ord.priceToman)}</span>
                      <span aria-hidden="true">·</span>
                      <span>UID: <strong className="font-mono">{ord.playerUid}</strong></span>
                      <span aria-hidden="true">·</span>
                      <span>{ord.createdAt}</span>
                    </div>

                    {ord.status === 'processing' && (
                      <div className="pt-2 max-w-md">
                        <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                          <span>{language === 'fa' ? 'در حال واریز از سرور اکتیویژن' : 'Injecting via Activision API'}</span>
                          <span className="text-[#00d9b5] font-bold">{language === 'fa' ? '۸۵٪ تکمیل' : '85% Injected'}</span>
                        </div>
                        <div className="w-full h-1.5 bg-[#070b0f] rounded-full overflow-hidden border border-slate-800">
                          <div className="w-[85%] h-full bg-[#00d9b5]" />
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-2 self-start md:self-center">
                    <button
                      onClick={() => setSelectedOrderDetails(ord)}
                      className="px-3 py-1.5 bg-[#0f1722] hover:bg-[#14202e] text-slate-300 hover:text-white border border-[#1b2a3a] rounded-lg text-xs font-semibold transition-colors"
                    >
                      {t.ucpOrderDetails}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 2: SAVED ACCOUNTS */}
      {activeSubTab === 'accounts' && (
        <div className="space-y-6">
          <div className="bg-[#0b1016] border border-[#16222f] rounded-2xl p-6 shadow-md">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-lg font-bold text-white">{t.ucpAccountsTitle}</h2>
                <p className="text-xs text-slate-400 mt-1">
                  {t.ucpAccountsDesc}
                </p>
              </div>

              <button
                onClick={() => setShowAddAccountModal(true)}
                className="px-4 py-2 bg-[#00d9b5] hover:bg-[#00c49f] text-[#06080b] font-bold text-xs rounded-xl shadow-sm flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>{t.ucpAddAccount}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {savedAccounts.map((acc) => (
                <InteractiveTilt key={acc.id} maxTilt={4.2} scale={1.02} elevationZ={14}>
                  <div className="bg-[#080d13] border border-[#162534] hover:border-[#00d9b5]/40 rounded-xl p-4 flex items-center justify-between transition-colors">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-white">{acc.accountName}</span>
                        {acc.isDefault && (
                          <span className="text-[10px] bg-[#00d9b5]/15 text-[#00d9b5] border border-[#00d9b5]/30 px-1.5 py-0.5 rounded">
                            {language === 'fa' ? 'پیش‌فرض' : 'Default'}
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-400 font-mono">
                        UID: {acc.playerUid}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {language === 'fa' ? `ریجن: ${acc.region}` : `Region: ${acc.region}`} · {acc.gameType === 'codm' ? (language === 'fa' ? 'کالاف موبایل' : 'COD Mobile') : 'Warzone'}
                      </div>
                    </div>

                    <button
                      onClick={() => deleteSavedAccount(acc.id)}
                      className="p-2 text-slate-500 hover:text-red-400 hover:bg-[#121c27] rounded-lg transition-colors"
                      title={language === 'fa' ? 'حذف اکانت' : 'Delete account'}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </InteractiveTilt>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 3: WALLET */}
      {activeSubTab === 'wallet' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          <div className="md:col-span-7 bg-[#0b1016] border border-[#16222f] rounded-2xl p-6 shadow-md">
            <h2 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-[#00d9b5]" />
              <span>{t.ucpWalletTitle}</span>
            </h2>
            <p className="text-xs text-slate-400 mb-6">
              {t.ucpWalletDesc}
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
              {[100000, 250000, 500000, 1000000].map((amt) => (
                <button
                  key={amt}
                  onClick={() => setDepositAmount(amt)}
                  className={`py-3 px-2 rounded-xl border text-center font-num transition-all ${
                    depositAmount === amt
                      ? 'bg-[#00d9b5]/15 border-[#00d9b5] text-[#00d9b5]'
                      : 'bg-[#080d13] border-slate-800 text-slate-300'
                  }`}
                >
                  <span className="block font-bold text-sm">
                    {language === 'fa' ? amt.toLocaleString('fa-IR') : amt.toLocaleString('en-US')}
                  </span>
                  <span className="text-[10px] text-slate-400">{t.currency}</span>
                </button>
              ))}
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => depositWallet(depositAmount)}
                className="w-full py-3 bg-[#00d9b5] hover:bg-[#00c49f] text-[#06080b] font-bold text-sm rounded-xl transition-all shadow-sm flex items-center justify-center gap-2"
              >
                <CreditCard className="w-4 h-4" />
                <span>
                  {language === 'fa' 
                    ? `پرداخت و افزایش ${depositAmount.toLocaleString('fa-IR')} تومان به کیف پول`
                    : `Deposit ${formatPrice(depositAmount)} to Wallet Balance`}
                </span>
              </button>
            </div>
          </div>

          <div className="md:col-span-5 bg-[#0b1016] border border-[#16222f] rounded-2xl p-6 shadow-md">
            <h2 className="text-base font-bold text-white mb-2 flex items-center gap-2">
              <Key className="w-4 h-4 text-[#00d9b5]" />
              <span>{t.ucpVoucherTitle}</span>
            </h2>
            <p className="text-xs text-slate-400 mb-4">
              {t.ucpVoucherDesc}
            </p>

            <form onSubmit={handleRedeemGift} className="space-y-3">
              <input
                type="text"
                value={giftCardCode}
                onChange={(e) => setGiftCardCode(e.target.value)}
                placeholder="WARZONE2026"
                className="w-full bg-[#080d13] border border-[#1b2838] focus:border-[#00d9b5] rounded-xl px-3.5 py-2.5 text-xs text-white uppercase font-mono focus:outline-none"
              />
              <button
                type="submit"
                className="w-full py-2.5 bg-[#121c27] hover:bg-[#182635] text-[#00d9b5] border border-[#00d9b5]/30 rounded-xl text-xs font-bold transition-colors"
              >
                {t.ucpVoucherApply}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* SUB-TAB 4: SECURITY */}
      {activeSubTab === 'security' && (
        <div className="bg-[#0b1016] border border-[#16222f] rounded-2xl p-6 space-y-6 shadow-md">
          <div className="flex items-center justify-between pb-6 border-b border-[#14202d]">
            <div>
              <h2 className="text-lg font-bold text-white">{t.ucpSecurityTitle}</h2>
              <p className="text-xs text-slate-400 mt-1">
                {t.ucpSecurityDesc}
              </p>
            </div>

            <span className="text-xs font-mono font-bold text-[#00d9b5] px-3 py-1 bg-[#00d9b5]/15 rounded-lg border border-[#00d9b5]/30">
              {t.ucpSecurityGrade}
            </span>
          </div>

          {/* 2FA Toggle */}
          <div className="flex items-center justify-between p-4 bg-[#080d13] border border-[#162534] rounded-xl">
            <div className="flex items-center gap-3">
              <Lock className="w-5 h-5 text-[#00d9b5]" />
              <div>
                <h3 className="text-sm font-bold text-white">{t.ucp2faTitle}</h3>
                <p className="text-xs text-slate-400">
                  {t.ucp2faDesc}
                </p>
              </div>
            </div>

            <button
              onClick={toggleTwoFactor}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${
                user.twoFactorEnabled
                  ? 'bg-[#00d9b5] text-[#06080b]'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {user.twoFactorEnabled ? t.ucp2faActive : t.ucp2faInactive}
            </button>
          </div>

          {/* Active Sessions */}
          <div>
            <h3 className="text-sm font-bold text-white mb-3">{t.ucpSessionsTitle}</h3>
            <div className="space-y-2">
              <div className="p-3 bg-[#080d13] border border-slate-800 rounded-xl flex items-center justify-between text-xs">
                <div>
                  <span className="text-white font-semibold">{t.ucpSessionCurrent}</span>
                  <div className="text-[11px] text-slate-500 font-mono">IP: 89.165.42.11 · TLS 1.3 Active</div>
                </div>
                <span className="text-[#00d9b5] font-mono text-[10px]">CURRENT</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Account Modal */}
      {showAddAccountModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" data-scroll-lock="true">
          <div className={`w-full max-w-md bg-[#0b1016] border border-[#1e2e3e] rounded-2xl p-6 shadow-2xl ${
            language === 'fa' ? 'text-right' : 'text-left'
          }`}>
            <h2 className="text-lg font-bold text-white mb-4">
              {language === 'fa' ? 'ذخیره اکانت بازی جدید' : 'Save New Game Account'}
            </h2>
            
            <form onSubmit={handleAddAccountSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-200 mb-1">
                  {language === 'fa' ? 'نام یا عنوان اکانت:' : 'Account Label:'}
                </label>
                <input
                  type="text"
                  required
                  value={newAccName}
                  onChange={(e) => setNewAccName(e.target.value)}
                  placeholder={language === 'fa' ? 'مثال: اکانت اصلی من' : 'e.g. My Primary Account'}
                  className="w-full bg-[#080d13] border border-slate-800 focus:border-[#00d9b5] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-200 mb-1">
                  {language === 'fa' ? 'آیدی عددی کالاف (UID):' : 'Player UID:'}
                </label>
                <input
                  type="text"
                  required
                  value={newAccUid}
                  onChange={(e) => setNewAccUid(e.target.value)}
                  placeholder="68924018294017263"
                  className="w-full bg-[#080d13] border border-slate-800 focus:border-[#00d9b5] rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-200 mb-1">
                    {language === 'fa' ? 'نوع بازی:' : 'Game Type:'}
                  </label>
                  <select
                    value={newAccType}
                    onChange={(e) => setNewAccType(e.target.value as GameType)}
                    className="w-full bg-[#080d13] border border-slate-800 text-xs text-white rounded-xl px-3 py-2 focus:outline-none"
                  >
                    <option value="codm">{language === 'fa' ? 'کالاف دیوتی موبایل' : 'COD Mobile'}</option>
                    <option value="warzone">{language === 'fa' ? 'وارزون (PC/Console)' : 'Warzone'}</option>
                    <option value="both">{language === 'fa' ? 'مشترک هر دو' : 'Both'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-200 mb-1">
                    {language === 'fa' ? 'ریجن اکانت:' : 'Region:'}
                  </label>
                  <select
                    value={newAccRegion}
                    onChange={(e) => setNewAccRegion(e.target.value)}
                    className="w-full bg-[#080d13] border border-slate-800 text-xs text-white rounded-xl px-3 py-2 focus:outline-none"
                  >
                    <option value="هند">{language === 'fa' ? 'هند (۲۲۰ سی‌پی)' : 'India (220 CP)'}</option>
                    <option value="ایران / خاورمیانه">{language === 'fa' ? 'ایران / خاورمیانه' : 'Middle East / Iran'}</option>
                    <option value="اروپا">{language === 'fa' ? 'اروپا' : 'Europe'}</option>
                    <option value="آمریکا">{language === 'fa' ? 'آمریکا' : 'USA'}</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#00d9b5] hover:bg-[#00c49f] text-[#06080b] font-bold text-xs rounded-xl"
                >
                  {language === 'fa' ? 'ذخیره اکانت' : 'Save Account'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddAccountModal(false)}
                  className="px-4 py-2.5 bg-[#121c27] text-slate-300 text-xs rounded-xl"
                >
                  {t.ticketCancel}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Order Details Modal */}
      {selectedOrderDetails && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" data-scroll-lock="true">
          <div className={`w-full max-w-md bg-[#0b1016] border border-[#1e2e3e] rounded-2xl p-6 shadow-2xl ${
            language === 'fa' ? 'text-right' : 'text-left'
          }`}>
            <h2 className="text-lg font-bold text-white mb-1">
              {language === 'fa' ? 'جزییات فاکتور سفارش' : 'Order Invoice Details'}
            </h2>
            <div className="text-xs font-mono text-[#00d9b5] mb-4">
              {t.checkoutTrackingCode} {selectedOrderDetails.orderCode}
            </div>

            <div className="space-y-3 bg-[#080d13] border border-slate-800 p-4 rounded-xl text-xs font-num">
              <div className="flex justify-between">
                <span className="text-slate-400">{language === 'fa' ? 'نام پکیج:' : 'Package:'}</span>
                <span className="text-white font-bold">{selectedOrderDetails.packageName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">{language === 'fa' ? 'حجم سی‌پی:' : 'CP Points:'}</span>
                <span className="text-[#00d9b5] font-bold">{language === 'fa' ? selectedOrderDetails.cpAmount.toLocaleString('fa-IR') : selectedOrderDetails.cpAmount.toLocaleString('en-US')} CP</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">{language === 'fa' ? 'مبلغ پرداختی:' : 'Price Paid:'}</span>
                <span className="text-white font-bold">{formatPrice(selectedOrderDetails.priceToman)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">{language === 'fa' ? 'UID بازیکن:' : 'Player UID:'}</span>
                <span className="text-white font-mono">{selectedOrderDetails.playerUid}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">{language === 'fa' ? 'ریجن اکانت:' : 'Region:'}</span>
                <span className="text-white">{selectedOrderDetails.region}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">{language === 'fa' ? 'زمان ثبت:' : 'Placed At:'}</span>
                <span className="text-slate-300">{selectedOrderDetails.createdAt}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">{language === 'fa' ? 'وضعیت فعلی:' : 'Status:'}</span>
                <span>{getOrderStatusDisplay(selectedOrderDetails.status)}</span>
              </div>
            </div>

            <button
              onClick={() => setSelectedOrderDetails(null)}
              className="w-full mt-4 py-2.5 bg-[#00d9b5] text-[#06080b] font-bold text-xs rounded-xl"
            >
              {language === 'fa' ? 'بستن پنجره' : 'Close'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
