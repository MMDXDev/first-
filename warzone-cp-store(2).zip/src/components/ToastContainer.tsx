import React from 'react';
import { useApp } from '../context/AppContext.tsx';
import { ShieldCheck, Info, AlertTriangle } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { notifications } = useApp();

  if (notifications.length === 0) return null;

  return (
    <div className="fixed top-24 left-1/2 -translate-x-1/2 z-50 flex flex-col items-center gap-2 pointer-events-none select-none max-w-md w-full px-4">
      {notifications.map((n) => (
        <div
          key={n.id}
          className="pointer-events-auto w-full bg-[#080d13]/95 border border-[#00d9b5]/40 rounded-xl p-3.5 shadow-xl flex items-center gap-3 backdrop-blur-md text-right transition-all animate-in fade-in slide-in-from-top-3 duration-200"
        >
          <div className="w-8 h-8 rounded-lg bg-[#00d9b5]/15 border border-[#00d9b5]/30 flex items-center justify-center text-[#00d9b5] shrink-0">
            {n.type === 'warn' ? (
              <AlertTriangle className="w-4 h-4" />
            ) : n.type === 'info' ? (
              <Info className="w-4 h-4" />
            ) : (
              <ShieldCheck className="w-4 h-4" />
            )}
          </div>
          <p className="text-xs sm:text-sm text-slate-100 font-medium leading-snug">
            {n.text}
          </p>
        </div>
      ))}
    </div>
  );
};
