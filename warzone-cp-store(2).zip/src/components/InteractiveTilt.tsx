import React, { useRef, useState, useEffect } from 'react';

interface Props {
  children: React.ReactNode;
  className?: string;
  maxTilt?: number; // Balanced 3D tilt angle
  enableGlare?: boolean;
  scale?: number;
  elevationZ?: number; // 3D elevation on Z axis
  enableAmbientReactive?: boolean;
}

export const InteractiveTilt: React.FC<Props> = ({
  children,
  className = '',
  maxTilt = 4.2, // Clearly noticeable, elegant 3D tilt
  enableGlare = true,
  scale = 1.018, // Clean 3D micro-lift
  elevationZ = 14, // Physical 3D extrusion depth in pixels
  enableAmbientReactive = true,
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [style, setStyle] = useState<React.CSSProperties>({
    transform: 'perspective(900px) rotateX(0deg) rotateY(0deg) translateZ(0px) scale3d(1, 1, 1)',
  });
  const [glarePos, setGlarePos] = useState({ x: 50, y: 50, opacity: 0 });
  const [isHovered, setIsHovered] = useState(false);

  // Subtle ambient breathing when mouse moves across viewport
  useEffect(() => {
    if (!enableAmbientReactive) return;

    const handleGlobalMouseMove = (e: MouseEvent) => {
      if (isHovered) return; // Direct hover takes precedence
      const card = cardRef.current;
      if (!card) return;

      const rect = card.getBoundingClientRect();
      if (rect.bottom < 0 || rect.top > window.innerHeight) return;

      const cardCenterX = rect.left + rect.width / 2;
      const cardCenterY = rect.top + rect.height / 2;

      const deltaX = (e.clientX - cardCenterX) / window.innerWidth;
      const deltaY = (e.clientY - cardCenterY) / window.innerHeight;

      const ambientRotX = (-deltaY * 0.8).toFixed(2);
      const ambientRotY = (deltaX * 0.8).toFixed(2);

      setStyle({
        transform: `perspective(900px) rotateX(${ambientRotX}deg) rotateY(${ambientRotY}deg) translateZ(0px) scale3d(1, 1, 1)`,
        transition: 'transform 500ms cubic-bezier(0.16, 1, 0.3, 1)',
      });
    };

    window.addEventListener('mousemove', handleGlobalMouseMove, { passive: true });
    return () => window.removeEventListener('mousemove', handleGlobalMouseMove);
  }, [enableAmbientReactive, isHovered]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const card = e.currentTarget;
    if (!card) return;

    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    // Calculate 3D angles
    const rotateX = Math.max(-maxTilt, Math.min(maxTilt, ((y - centerY) / centerY) * -maxTilt));
    const rotateY = Math.max(-maxTilt, Math.min(maxTilt, ((x - centerX) / centerX) * maxTilt));

    // Calculate dynamic 3D shadow displacement
    const shadowX = (rotateY * 1.5).toFixed(1);
    const shadowY = (-rotateX * 1.5 + 14).toFixed(1);

    setIsHovered(true);
    setStyle({
      transform: `perspective(900px) rotateX(${rotateX.toFixed(2)}deg) rotateY(${rotateY.toFixed(2)}deg) translateZ(${elevationZ}px) scale3d(${scale}, ${scale}, 1)`,
      boxShadow: `${-shadowX}px ${shadowY}px 32px -8px rgba(0, 0, 0, 0.75), 0 0 24px -4px rgba(0, 217, 181, 0.16)`,
      transition: 'transform 160ms cubic-bezier(0.2, 0.9, 0.3, 1), box-shadow 160ms ease-out',
    });

    if (enableGlare) {
      setGlarePos({
        x: Math.round((x / rect.width) * 100),
        y: Math.round((y / rect.height) * 100),
        opacity: 0.16,
      });
    }
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setStyle({
      transform: 'perspective(900px) rotateX(0deg) rotateY(0deg) translateZ(0px) scale3d(1, 1, 1)',
      boxShadow: 'none',
      transition: 'transform 450ms cubic-bezier(0.16, 1, 0.3, 1), box-shadow 450ms ease-out',
    });
    if (enableGlare) {
      setGlarePos(prev => ({ ...prev, opacity: 0 }));
    }
  };

  return (
    <div
      ref={cardRef}
      onMouseEnter={handleMouseEnter}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={`relative will-change-transform transform-gpu [transform-style:preserve-3d] ${className}`}
      style={style}
    >
      {children}

      {/* 3D Specular Highlight & Glare that follows the mouse angle */}
      {enableGlare && (
        <div
          className="absolute inset-0 rounded-[inherit] pointer-events-none transition-opacity duration-300"
          style={{
            opacity: glarePos.opacity,
            background: `radial-gradient(circle 260px at ${glarePos.x}% ${glarePos.y}%, rgba(0, 217, 181, 0.22) 0%, rgba(255, 255, 255, 0.05) 30%, transparent 75%)`,
          }}
        />
      )}
    </div>
  );
};
