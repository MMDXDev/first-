import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { CPPackage } from '../types/index.ts';
import { X, ShieldCheck, Zap, Lock, CreditCard, Wallet, Coins, CheckCircle2 } from 'lucide-react';

export const PurchaseModal: React.FC = () => {
  const { 
    user, 
    savedAccounts, 
    createOrder, 
    depositWallet, 
    setActiveTab, 
    selectedPackageForBuy, 
    setSelectedPackageForBuy,
    showToast,
    language,
    t
  } = useApp();
  const pkg = selectedPackageForBuy;

  const [playerUid, setPlayerUid] = useState(user.playerUid || '');
  const [playerTag, setPlayerTag] = useState(user.activisionId || '');
  const [activisionEmail, setActivisionEmail] = useState('');
  const [activisionPass, setActivisionPass] = useState('');
  const [region, setRegion] = useState(language === 'fa' ? 'ایران / خاورمیانه' : 'Middle East / Global');
  const [paymentMethod, setPaymentMethod] = useState<'gateway' | 'wallet' | 'crypto'>('gateway');
  const [coupon, setCoupon] = useState('');
  const [discountApplied, setDiscountApplied] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successOrderCode, setSuccessOrderCode] = useState<string | null>(null);

  if (!pkg) return null;

  const finalPrice = Math.max(0, pkg.priceToman - discountApplied);

  const formatPrice = (priceToman: number) => {
    if (language === 'fa') {
      return `${priceToman.toLocaleString('fa-IR')} ${t.currency}`;
    }
    const approxUsd = (priceToman / 50000).toFixed(2);
    return `$${approxUsd} USD`;
  };

  const handleClose = () => {
    setSelectedPackageForBuy(null);
  };

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (coupon.trim().toUpperCase() === 'WARZONE2026') {
      const discount = Math.round(pkg.priceToman * 0.1);
      setDiscountApplied(discount);
      showToast(t.checkoutCouponSuccess, 'success');
    } else {
      showToast(
        language === 'fa' ? 'کد تخفیف معتبر نیست. کد تست: WARZONE2026' : 'Invalid promo code. Test code: WARZONE2026',
        'warn'
      );
    }
  };

  const handleSelectSavedAccount = (accUid: string, accRegion: string) => {
    setPlayerUid(accUid);
    setRegion(accRegion);
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!playerUid.trim()) {
      showToast(
        language === 'fa' ? 'لطفا UID اکانت کالاف خود را وارد نمایید.' : 'Please enter your Player UID.',
        'warn'
      );
      return;
    }

    if (paymentMethod === 'wallet' && user.walletBalance < finalPrice) {
      showToast(
        language === 'fa' 
          ? 'موجودی کیف پول شما کافی نیست. لطفا از درگاه پرداخت شتاب استفاده کنید یا کیف پول را شارژ نمایید.'
          : 'Insufficient wallet balance. Please choose Card Payment or top up your wallet.',
        'warn'
      );
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      if (paymentMethod === 'wallet') {
        depositWallet(-finalPrice);
      }

      const order = createOrder(
        pkg,
        playerUid,
        region,
        playerTag,
        activisionEmail || undefined,
        pkg.deliveryType === 'activision_login' 
          ? (language === 'fa' ? 'شارژ مستقیم از طریق سرور اکتیویژن' : 'Direct Activision server deposit') 
          : (language === 'fa' ? 'واریز قانونی با آیدی عددی UID' : 'Player UID fast top-up')
      );

      setIsSubmitting(false);
      setSuccessOrderCode(order.orderCode);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto" data-scroll-lock="true">
      <div className={`relative w-full max-w-lg bg-[#0b1016] border border-[#1e2e3e] rounded-2xl p-6 sm:p-8 my-8 overflow-hidden shadow-2xl ${
        language === 'fa' ? 'text-right' : 'text-left'
      }`}>
        {/* Subtle Top Accent Bar */}
        <div className="absolute top-0 right-0 left-0 h-0.5 bg-[#00d9b5]" />

        {/* Close Button */}
        <button
          onClick={handleClose}
          className={`absolute top-4 ${language === 'fa' ? 'left-4' : 'right-4'} p-2 text-slate-400 hover:text-[#00d9b5] hover:bg-[#121c27] rounded-lg transition-colors`}
        >
          <X className="w-5 h-5" />
        </button>

        {successOrderCode ? (
          /* Success Screen */
          <div className="py-6 flex flex-col items-center text-center">
            <div className="w-16 h-16 rounded-full bg-[#00d9b5]/15 border border-[#00d9b5] flex items-center justify-center text-[#00d9b5] mb-4">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <h3 className="text-xl font-bold text-white mb-2">{t.checkoutSuccessTitle}</h3>
            <p className="text-sm text-slate-300 max-w-sm mb-6 leading-relaxed">
              {t.checkoutSuccessDesc}
            </p>

            {/* Tracking Code */}
            <div className="w-full bg-[#070b0f] border border-[#172533] rounded-xl p-4 mb-6">
              <span className="text-xs text-slate-400 block mb-1">{t.checkoutTrackingCode}</span>
              <span className="text-2xl font-mono font-bold text-[#00d9b5] tracking-widest">{successOrderCode}</span>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 w-full">
              <button
                onClick={() => {
                  handleClose();
                  setActiveTab('ucp');
                }}
                className="flex-1 py-3 px-4 bg-[#00d9b5] hover:bg-[#00c49f] text-[#06080b] font-bold text-sm rounded-xl transition-all shadow-sm"
              >
                {t.checkoutViewUcp}
              </button>
              <button
                onClick={handleClose}
                className="py-3 px-4 bg-[#111923] hover:bg-[#172332] text-slate-300 font-medium text-sm rounded-xl border border-slate-700 transition-colors"
              >
                {t.checkoutClose}
              </button>
            </div>
          </div>
        ) : (
          /* Order Form */
          <>
            <div className="mb-6">
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span>{t.checkoutTitle}</span>
                <span className="text-[#00d9b5] font-mono font-semibold">{t.checkoutHeader}</span>
              </div>
              <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
                <span>{language === 'fa' ? pkg.title : `${pkg.cpAmount} CP Bundle`}</span>
                <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-[#00d9b5]/15 text-[#00d9b5] border border-[#00d9b5]/30">
                  +{pkg.cpAmount + pkg.bonusCp} CP
                </span>
              </h2>
            </div>

            {/* Quick Package Summary */}
            <div className="bg-[#070a0e] border border-[#141e2a] rounded-xl p-3.5 mb-6 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#0d1621] border border-[#00d9b5]/30 flex items-center justify-center text-[#00d9b5]">
                  <Coins className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-slate-400">{t.checkoutFinalCp}</div>
                  <div className="text-sm font-bold text-white font-num">
                    {language === 'fa' 
                      ? `${(pkg.cpAmount + pkg.bonusCp).toLocaleString('fa-IR')} عدد`
                      : `${(pkg.cpAmount + pkg.bonusCp).toLocaleString('en-US')} CP`}
                  </div>
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-400">{t.checkoutPayable}</div>
                <div className="text-base font-extrabold text-[#00d9b5] font-num">
                  {formatPrice(finalPrice)}
                </div>
              </div>
            </div>

            <form onSubmit={handleSubmitOrder} className="space-y-4">
              {/* Saved accounts selector if any */}
              {savedAccounts.length > 0 && (
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    {t.checkoutSavedLabel}
                  </label>
                  <div className="flex gap-2 overflow-x-auto pb-1">
                    {savedAccounts.map((acc) => (
                      <button
                        type="button"
                        key={acc.id}
                        onClick={() => handleSelectSavedAccount(acc.playerUid, acc.region)}
                        className={`text-xs px-2.5 py-1.5 rounded-lg border whitespace-nowrap transition-colors ${
                          playerUid === acc.playerUid
                            ? 'bg-[#00d9b5]/15 border-[#00d9b5] text-[#00d9b5]'
                            : 'bg-[#0f1722] border-slate-800 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {acc.accountName}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Player UID Input */}
              <div>
                <label className="block text-xs font-semibold text-slate-200 mb-1">
                  {t.checkoutUidLabel} <span className="text-[#00d9b5]">*</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={playerUid}
                    onChange={(e) => setPlayerUid(e.target.value)}
                    placeholder="68924018294017263"
                    className={`w-full bg-[#080d13] border border-[#1b2838] focus:border-[#00d9b5] rounded-xl py-2.5 text-sm text-white font-mono placeholder:text-slate-600 focus:outline-none transition-colors ${
                      language === 'fa' ? 'px-3.5 pr-3.5 pl-12' : 'px-3.5 pl-3.5 pr-12'
                    }`}
                  />
                  <div className={`absolute top-1/2 -translate-y-1/2 text-[10px] font-mono text-slate-500 ${
                    language === 'fa' ? 'left-3' : 'right-3'
                  }`}>
                    UID
                  </div>
                </div>
                <span className="text-[11px] text-slate-400 mt-1 block">
                  {t.checkoutUidHint}
                </span>
              </div>

              {/* Player Tag */}
              <div>
                <label className="block text-xs font-semibold text-slate-200 mb-1">
                  {t.checkoutTagLabel}
                </label>
                <input
                  type="text"
                  value={playerTag}
                  onChange={(e) => setPlayerTag(e.target.value)}
                  placeholder="Ghost_Sniper#98214"
                  className="w-full bg-[#080d13] border border-[#1b2838] focus:border-[#00d9b5] rounded-xl px-3.5 py-2.5 text-sm text-white placeholder:text-slate-600 focus:outline-none transition-colors"
                />
              </div>

              {/* Region Select */}
              <div>
                <label className="block text-xs font-semibold text-slate-200 mb-1">
                  {t.checkoutRegionLabel}
                </label>
                <select
                  value={region}
                  onChange={(e) => setRegion(e.target.value)}
                  className="w-full bg-[#080d13] border border-[#1b2838] focus:border-[#00d9b5] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none transition-colors"
                >
                  <option value="هند">{language === 'fa' ? 'هند (ارزان‌ترین قیمت گردونه - ۲۲۰ بتل پس)' : 'India (Lowest Draw Costs - 220 Battle Pass)'}</option>
                  <option value="ایران / خاورمیانه">{language === 'fa' ? 'ایران / خاورمیانه (معمولاً ۲۲۰ یا ۳۶۰ سی‌پی بتل پس)' : 'Middle East / Iran (220-360 Battle Pass)'}</option>
                  <option value="اروپا">{language === 'fa' ? 'اروپا (۵۶۰ بتل پس)' : 'Europe (560 Battle Pass)'}</option>
                  <option value="آمریکا">{language === 'fa' ? 'آمریکا (۵۶۰ بتل پس)' : 'Americas / Global (560 Battle Pass)'}</option>
                </select>
              </div>

              {/* If package requires Activision Login */}
              {pkg.deliveryType === 'activision_login' && (
                <div className="p-3.5 rounded-xl bg-[#090f17] border border-[#1a2736] space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-[#00d9b5]">
                    <Lock className="w-3.5 h-3.5" />
                    <span>{t.checkoutActivisionLogin}</span>
                  </div>
                  <div>
                    <input
                      type="email"
                      required
                      value={activisionEmail}
                      onChange={(e) => setActivisionEmail(e.target.value)}
                      placeholder={t.checkoutActivisionEmail}
                      className="w-full bg-[#060a0f] border border-slate-800 focus:border-[#00d9b5] rounded-lg px-3 py-2 text-xs text-white placeholder:text-slate-600 focus:outline-none"
                    />
                  </div>
                  <div>
                    <input
                      type="password"
                      required
                      value={activisionPass}
                      onChange={(e) => setActivisionPass(e.target.value)}
                      placeholder={t.checkoutActivisionPass}
                      className="w-full bg-[#060a0f] border border-slate-800 focus:border-[#00d9b5] rounded-lg px-3 py-2 text-xs text-white placeholder:text-slate-600 focus:outline-none"
                    />
                  </div>
                  <div className="text-[10px] text-slate-400 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-[#00d9b5]" />
                    <span>{t.checkoutActivisionNote}</span>
                  </div>
                </div>
              )}

              {/* Coupon Code */}
              <div className="flex gap-2">
                <input
                  type="text"
                  value={coupon}
                  onChange={(e) => setCoupon(e.target.value)}
                  placeholder={t.checkoutCouponPlaceholder}
                  className="flex-1 bg-[#080d13] border border-[#1b2838] focus:border-[#00d9b5] rounded-xl px-3 py-2 text-xs text-white placeholder:text-slate-600 focus:outline-none font-mono uppercase"
                />
                <button
                  type="button"
                  onClick={handleApplyCoupon}
                  className="px-3 py-2 bg-[#101a24] hover:bg-[#162534] text-[#00d9b5] border border-[#00d9b5]/30 rounded-xl text-xs font-semibold transition-colors"
                >
                  {t.checkoutCouponApply}
                </button>
              </div>

              {discountApplied > 0 && (
                <div className="text-xs text-[#00d9b5] flex items-center justify-between">
                  <span>{t.checkoutCouponSuccess}</span>
                  <span className="font-num font-bold">-{formatPrice(discountApplied)}</span>
                </div>
              )}

              {/* Payment Method Selector */}
              <div>
                <label className="block text-xs font-semibold text-slate-200 mb-2">
                  {t.checkoutPayMethodLabel}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('gateway')}
                    className={`flex flex-col items-center justify-center p-2.5 rounded-xl border text-center transition-all ${
                      paymentMethod === 'gateway'
                        ? 'bg-[#00d9b5]/15 border-[#00d9b5] text-[#00d9b5]'
                        : 'bg-[#080d13] border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 mb-1" />
                    <span className="text-[11px] font-bold">{t.checkoutMethodShetab}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('wallet')}
                    className={`flex flex-col items-center justify-center p-2.5 rounded-xl border text-center transition-all ${
                      paymentMethod === 'wallet'
                        ? 'bg-[#00d9b5]/15 border-[#00d9b5] text-[#00d9b5]'
                        : 'bg-[#080d13] border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <Wallet className="w-4 h-4 mb-1" />
                    <span className="text-[11px] font-bold">{t.checkoutMethodWallet}</span>
                    <span className="text-[9px] opacity-75 font-num">
                      ({formatPrice(user.walletBalance)})
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('crypto')}
                    className={`flex flex-col items-center justify-center p-2.5 rounded-xl border text-center transition-all ${
                      paymentMethod === 'crypto'
                        ? 'bg-[#00d9b5]/15 border-[#00d9b5] text-[#00d9b5]'
                        : 'bg-[#080d13] border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <Zap className="w-4 h-4 mb-1" />
                    <span className="text-[11px] font-bold">{t.checkoutMethodCrypto}</span>
                  </button>
                </div>
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 px-4 bg-[#00d9b5] hover:bg-[#00c49f] disabled:opacity-50 text-[#06080b] font-extrabold text-sm rounded-xl transition-all shadow-sm flex items-center justify-center gap-2 mt-4"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                    <span>{t.checkoutProcessing}</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-5 h-5" />
                    <span>{t.checkoutPayBtn} ({formatPrice(finalPrice)})</span>
                  </>
                )}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
};
