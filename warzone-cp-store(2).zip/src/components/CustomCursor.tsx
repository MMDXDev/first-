import React, { useEffect, useState, useRef } from 'react';

export const CustomCursor: React.FC = () => {
  const [enabled, setEnabled] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [isClicking, setIsClicking] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  // Precision tracking
  const pos = useRef({ x: -100, y: -100 });
  const cursorRef = useRef<HTMLDivElement>(null);
  const animFrameId = useRef<number | null>(null);

  useEffect(() => {
    // Only enable on devices with fine pointer (mouse/trackpad), never on touch screens
    const hasFinePointer = window.matchMedia('(pointer: fine)').matches;
    if (!hasFinePointer) {
      setEnabled(false);
      return;
    }

    setEnabled(true);
    document.body.classList.add('custom-cursor-active');

    const handleMouseMove = (e: MouseEvent) => {
      setIsVisible(true);
      pos.current = { x: e.clientX, y: e.clientY };

      const target = e.target as HTMLElement | null;
      if (target) {
        const interactive = target.closest(
          'button, a, input, select, textarea, [role="button"], [data-interactive="true"]'
        );
        setIsHovered(!!interactive);
      }
    };

    const handleMouseDown = () => setIsClicking(true);
    const handleMouseUp = () => setIsClicking(false);
    const handleMouseLeave = () => setIsVisible(false);
    const handleMouseEnter = () => setIsVisible(true);

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    document.addEventListener('mouseleave', handleMouseLeave);
    document.addEventListener('mouseenter', handleMouseEnter);

    // Direct render loop - strictly lock reticle around the center dot
    const render = () => {
      if (cursorRef.current) {
        cursorRef.current.style.transform = `translate3d(${pos.current.x}px, ${pos.current.y}px, 0)`;
      }
      animFrameId.current = requestAnimationFrame(render);
    };

    animFrameId.current = requestAnimationFrame(render);

    return () => {
      document.body.classList.remove('custom-cursor-active');
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('mouseenter', handleMouseEnter);
      if (animFrameId.current) {
        cancelAnimationFrame(animFrameId.current);
      }
    };
  }, []);

  if (!enabled || !isVisible) return null;

  return (
    <div
      ref={cursorRef}
      className="fixed top-0 left-0 pointer-events-none z-[9999] will-change-transform select-none"
      style={{
        transform: `translate3d(${pos.current.x}px, ${pos.current.y}px, 0)`,
      }}
    >
      {/* 
        Container centered exactly at (0, 0)
        Both the inner dot and the outer reticle share the exact same mathematical origin (0, 0).
      */}
      <div className="relative flex items-center justify-center w-0 h-0">
        {/* Precision Center Aim Dot */}
        <div
          className={`absolute rounded-full transition-transform duration-100 pointer-events-none -translate-x-1/2 -translate-y-1/2 ${
            isClicking ? 'w-1 h-1 bg-[#00d9b5]' : 'w-1.5 h-1.5 bg-[#00d9b5]'
          }`}
          style={{ left: 0, top: 0 }}
        />

        {/* Concentric Tactical Reticle - Directly centered around the dot, clean matte finish without neon bloom */}
        <div
          className={`absolute rounded-full border transition-all duration-150 ease-out flex items-center justify-center pointer-events-none -translate-x-1/2 -translate-y-1/2 ${
            isHovered
              ? 'w-8 h-8 border-[#00d9b5] bg-[#00d9b5]/10 scale-105'
              : isClicking
              ? 'w-5 h-5 border-[#00d9b5] bg-[#00d9b5]/20 scale-90'
              : 'w-6 h-6 border-[#00d9b5]/60'
          }`}
          style={{ left: 0, top: 0 }}
        >
          {/* Tactical Crosshair Notch Marks */}
          <span className="absolute top-0 left-1/2 -translate-x-1/2 w-0.5 h-1 bg-[#00d9b5]/80" />
          <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0.5 h-1 bg-[#00d9b5]/80" />
          <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-0.5 bg-[#00d9b5]/80" />
          <span className="absolute right-0 top-1/2 -translate-y-1/2 w-1 h-0.5 bg-[#00d9b5]/80" />

          {/* Target Corner Brackets on Hover */}
          {isHovered && (
            <div className="absolute inset-0 pointer-events-none">
              <span className="absolute -top-1 -right-1 w-1.5 h-1.5 border-t border-r border-[#00d9b5]" />
              <span className="absolute -top-1 -left-1 w-1.5 h-1.5 border-t border-l border-[#00d9b5]" />
              <span className="absolute -bottom-1 -right-1 w-1.5 h-1.5 border-b border-r border-[#00d9b5]" />
              <span className="absolute -bottom-1 -left-1 w-1.5 h-1.5 border-b border-l border-[#00d9b5]" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
