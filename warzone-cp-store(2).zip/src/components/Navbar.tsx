import React from 'react';
import { useApp } from '../context/AppContext.tsx';
import { Shield, Zap, User, Headphones, ShoppingBag, LayoutDashboard, Globe } from 'lucide-react';

export const Navbar: React.FC = () => {
  const { activeTab, setActiveTab, user, setSelectedPackageForBuy, packages, language, setLanguage, t } = useApp();

  const handleQuickBuy = () => {
    const popularPkg = packages.find(p => p.isPopular) || packages[0];
    if (popularPkg) {
      setSelectedPackageForBuy(popularPkg);
    }
  };

  const toggleLanguage = () => {
    setLanguage(language === 'fa' ? 'en' : 'fa');
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#06080b]/95 backdrop-blur-md border-b border-[#141e2a]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4 lg:gap-8">
        
        {/* Zone 1: Brand Wordmark */}
        <button
          onClick={() => setActiveTab('home')}
          className={`flex items-center gap-3 text-slate-100 hover:text-[#00d9b5] transition-colors whitespace-nowrap shrink-0 ${
            language === 'fa' ? 'text-right' : 'text-left'
          }`}
        >
          <div className="w-9 h-9 rounded-lg bg-[#0c141d] border border-[#00d9b5]/40 flex items-center justify-center text-[#00d9b5] shadow-sm">
            <Shield className="w-5 h-5" />
          </div>
          <div className="flex flex-col">
            <span className="font-extrabold text-xl tracking-tight text-white flex items-center gap-1.5">
              <span>{t.brandTitle}</span>
              <span className="text-[10px] font-mono font-bold tracking-widest text-[#00d9b5] uppercase">{t.brandBadge}</span>
            </span>
            <span className="text-[11px] text-slate-400 font-num">{t.brandSubtitle}</span>
          </div>
        </button>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 lg:gap-8 text-sm font-medium">
          <button
            onClick={() => setActiveTab('home')}
            className={`whitespace-nowrap shrink-0 py-2 transition-colors relative ${
              activeTab === 'home'
                ? 'text-[#00d9b5] font-semibold'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            {t.navHome}
            {activeTab === 'home' && (
              <span className="absolute bottom-0 right-0 left-0 h-0.5 bg-[#00d9b5]" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('store')}
            className={`whitespace-nowrap shrink-0 py-2 transition-colors relative flex items-center gap-1.5 ${
              activeTab === 'store'
                ? 'text-[#00d9b5] font-semibold'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <ShoppingBag className="w-4 h-4 text-[#00d9b5]" />
            <span>{t.navStore}</span>
            {activeTab === 'store' && (
              <span className="absolute bottom-0 right-0 left-0 h-0.5 bg-[#00d9b5]" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('tickets')}
            className={`whitespace-nowrap shrink-0 py-2 transition-colors relative flex items-center gap-1.5 ${
              activeTab === 'tickets'
                ? 'text-[#00d9b5] font-semibold'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <Headphones className="w-4 h-4 text-[#00d9b5]" />
            <span>{t.navTickets}</span>
            {activeTab === 'tickets' && (
              <span className="absolute bottom-0 right-0 left-0 h-0.5 bg-[#00d9b5]" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('ucp')}
            className={`whitespace-nowrap shrink-0 py-2 transition-colors relative flex items-center gap-1.5 ${
              activeTab === 'ucp'
                ? 'text-[#00d9b5] font-semibold'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <User className="w-4 h-4 text-[#00d9b5]" />
            <span>{t.navUcp}</span>
            {activeTab === 'ucp' && (
              <span className="absolute bottom-0 right-0 left-0 h-0.5 bg-[#00d9b5]" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('admin')}
            className={`whitespace-nowrap shrink-0 py-2 transition-colors relative flex items-center gap-1.5 ${
              activeTab === 'admin'
                ? 'text-[#00d9b5] font-semibold'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <LayoutDashboard className="w-4 h-4 text-[#00d9b5]" />
            <span>{t.navAdmin}</span>
            {activeTab === 'admin' && (
              <span className="absolute bottom-0 right-0 left-0 h-0.5 bg-[#00d9b5]" />
            )}
          </button>
        </nav>

        {/* Zone 3: Language Switcher + Wallet + Quick CTA */}
        <div className="flex items-center gap-3 shrink-0">
          
          {/* Tactical Language Switcher Button */}
          <button
            onClick={toggleLanguage}
            title={language === 'fa' ? 'Switch to English' : 'تغییر به زبان فارسی'}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#0c141d] border border-[#1a2938] hover:border-[#00d9b5]/50 text-xs font-mono font-bold text-slate-200 hover:text-[#00d9b5] transition-all"
          >
            <Globe className="w-3.5 h-3.5 text-[#00d9b5]" />
            <span>{language === 'fa' ? 'EN' : 'فا'}</span>
            <span className="text-[10px] text-slate-400 border-l border-slate-700 pl-1 ml-0.5">
              {language === 'fa' ? 'انگلیسی' : 'Persian'}
            </span>
          </button>

          {/* Wallet Balance widget */}
          <div 
            onClick={() => setActiveTab('ucp')}
            className={`hidden sm:flex flex-col cursor-pointer group px-3 ${
              language === 'fa' ? 'text-right border-r border-slate-800' : 'text-left border-l border-slate-800'
            }`}
          >
            <span className="text-[10px] text-slate-400 font-num">{t.walletBalance}</span>
            <span className="text-xs font-bold text-[#00d9b5] font-num group-hover:underline">
              {language === 'fa' 
                ? `${user.walletBalance.toLocaleString('fa-IR')} ${t.currency}`
                : `$${(user.walletBalance / 50000).toFixed(2)} USD`
              }
            </span>
          </div>

          {/* Quick Buy Button */}
          <button
            onClick={handleQuickBuy}
            className="flex items-center gap-2 px-4 py-2 text-xs font-bold text-[#06080b] bg-[#00d9b5] hover:bg-[#00c49f] transition-all rounded-lg whitespace-nowrap shrink-0 shadow-sm"
          >
            <Zap className="w-4 h-4 fill-current" />
            <span>{t.quickBuy}</span>
          </button>
        </div>
      </div>

      {/* Mobile Subnav Strip */}
      <div className="flex md:hidden items-center justify-around px-2 py-2.5 bg-[#080d13] border-t border-slate-800/80 text-xs font-medium">
        <button
          onClick={() => setActiveTab('home')}
          className={`px-2 py-1 ${activeTab === 'home' ? 'text-[#00d9b5] font-bold' : 'text-slate-400'}`}
        >
          {t.navHome}
        </button>
        <button
          onClick={() => setActiveTab('store')}
          className={`px-2 py-1 ${activeTab === 'store' ? 'text-[#00d9b5] font-bold' : 'text-slate-400'}`}
        >
          {t.navStore}
        </button>
        <button
          onClick={() => setActiveTab('tickets')}
          className={`px-2 py-1 ${activeTab === 'tickets' ? 'text-[#00d9b5] font-bold' : 'text-slate-400'}`}
        >
          {t.navTickets}
        </button>
        <button
          onClick={() => setActiveTab('ucp')}
          className={`px-2 py-1 ${activeTab === 'ucp' ? 'text-[#00d9b5] font-bold' : 'text-slate-400'}`}
        >
          {t.navUcp}
        </button>
        <button
          onClick={() => setActiveTab('admin')}
          className={`px-2 py-1 ${activeTab === 'admin' ? 'text-[#00d9b5] font-bold' : 'text-slate-400'}`}
        >
          {t.navAdmin}
        </button>
      </div>
    </header>
  );
};
