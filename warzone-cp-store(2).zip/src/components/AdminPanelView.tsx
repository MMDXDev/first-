import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { GameType, DeliveryType } from '../types/index.ts';
import { InteractiveTilt } from './InteractiveTilt.tsx';
import { 
  ShoppingBag, 
  Package, 
  Database, 
  ShieldCheck, 
  Users, 
  Zap, 
  CheckCircle, 
  Clock, 
  Plus, 
  Trash2, 
  Edit3, 
  Server,
  Lock,
  Activity,
  Terminal
} from 'lucide-react';

type AdminTab = 'orders' | 'catalog' | 'postgres' | 'users';

export const AdminPanelView: React.FC = () => {
  const { 
    orders, 
    packages, 
    auditLogs, 
    updateOrderStatus, 
    addPackage, 
    updatePackage, 
    deletePackage,
    user,
    showToast,
    language,
    t
  } = useApp();

  const [activeTab, setActiveTab] = useState<AdminTab>('orders');
  const [orderFilter, setOrderFilter] = useState<string>('all');

  const [showAddPackageModal, setShowAddPackageModal] = useState(false);
  const [pkgTitle, setPkgTitle] = useState('');
  const [pkgCp, setPkgCp] = useState(880);
  const [pkgBonus, setPkgBonus] = useState(50);
  const [pkgPrice, setPkgPrice] = useState(490000);
  const [pkgGameType, setPkgGameType] = useState<GameType>('codm');
  const [pkgDeliveryType, setPkgDeliveryType] = useState<DeliveryType>('uid_only');
  const [pkgDesc, setPkgDesc] = useState('');

  const [sqlTestQuery, setSqlTestQuery] = useState("SELECT count(*) FROM orders WHERE status = 'delivered';");
  const [sqlTestResult, setSqlTestResult] = useState<string | null>(null);

  const formatPrice = (priceToman: number) => {
    if (language === 'fa') {
      return `${priceToman.toLocaleString('fa-IR')} ${t.currency}`;
    }
    const approxUsd = (priceToman / 50000).toFixed(2);
    return `$${approxUsd} USD`;
  };

  const handleExecuteSafeSql = (e: React.FormEvent) => {
    e.preventDefault();
    setSqlTestResult(
      language === 'fa'
        ? "QUERY PLAN: Index Scan using idx_orders_status on orders (cost=0.15..8.17 rows=42 width=8) | Execution Time: 1.12ms | Security: Prepared Statement Sanitized [OK]"
        : "QUERY PLAN: Index Scan using idx_orders_status on orders (cost=0.15..8.17 rows=42 width=8) | Execution Time: 1.12ms | Security: Prepared Statement Sanitized [OK]"
    );
    showToast(
      language === 'fa'
        ? 'کوئری امن PostgreSQL با موفقیت ارزیابی شد.'
        : 'PostgreSQL sanitized query evaluated successfully.'
    );
  };

  const handleCreatePackage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pkgTitle) {
      showToast(
        language === 'fa' ? 'لطفا عنوان پکیج را وارد کنید.' : 'Please enter the package title.',
        'warn'
      );
      return;
    }
    addPackage({
      title: pkgTitle,
      cpAmount: Number(pkgCp),
      bonusCp: Number(pkgBonus),
      priceToman: Number(pkgPrice),
      originalPriceToman: Math.round(Number(pkgPrice) * 1.15),
      gameType: pkgGameType,
      deliveryType: pkgDeliveryType,
      inStock: true,
      category: 'custom_admin',
      description: pkgDesc || (language === 'fa' ? 'پکیج افزوده شده توسط سرپرست سیستم' : 'Custom package added by system admin'),
      image: '/src/assets/images/cp_points_vault_1792428987465.jpg',
    });
    setShowAddPackageModal(false);
    setPkgTitle('');
    setPkgDesc('');
  };

  const filteredOrders = orders.filter(o => {
    if (orderFilter === 'all') return true;
    return o.status === orderFilter;
  });

  const totalRevenue = orders.reduce((sum, o) => sum + o.priceToman, 0);
  const totalCpDelivered = orders.filter(o => o.status === 'delivered').reduce((sum, o) => sum + o.cpAmount, 0);
  const pendingOrdersCount = orders.filter(o => o.status === 'processing' || o.status === 'pending').length;

  return (
    <div className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 pb-24 ${
      language === 'fa' ? 'text-right' : 'text-left'
    }`}>
      {/* Admin Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#00d9b5] mb-1">
            <span>{t.adminHeader}</span>
            <span aria-hidden="true">·</span>
            <span>{t.adminSubtitle}</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white">
            {t.adminTitle}
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-[#080d13] border border-slate-700 px-3 py-1.5 rounded-xl flex items-center gap-2 text-xs text-[#00d9b5] font-mono">
            <span className="w-2 h-2 rounded-full bg-[#00d9b5]" />
            <span>{t.adminPostgresActive}</span>
          </div>
        </div>
      </div>

      {/* KPI Stats Grid with 3D Depth */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8 font-num">
        <InteractiveTilt maxTilt={4.0} scale={1.02} elevationZ={14}>
          <div className="bg-[#0b1016] border border-[#16222f] hover:border-[#00d9b5]/40 rounded-2xl p-5 h-full transition-colors shadow-md">
            <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
              <span>{t.adminKpiRevenue}</span>
              <ShoppingBag className="w-4 h-4 text-[#00d9b5]" />
            </div>
            <div className="text-2xl font-black text-white">
              {formatPrice(totalRevenue)}
            </div>
            <div className="text-[10px] text-[#00d9b5] mt-1 font-mono">{t.adminKpiRevenueNote}</div>
          </div>
        </InteractiveTilt>

        <InteractiveTilt maxTilt={4.0} scale={1.02} elevationZ={14}>
          <div className="bg-[#0b1016] border border-[#16222f] hover:border-[#00d9b5]/40 rounded-2xl p-5 h-full transition-colors shadow-md">
            <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
              <span>{t.adminKpiCp}</span>
              <Zap className="w-4 h-4 text-[#00d9b5]" />
            </div>
            <div className="text-2xl font-black text-[#00d9b5]">
              {language === 'fa' ? totalCpDelivered.toLocaleString('fa-IR') : totalCpDelivered.toLocaleString('en-US')} <span className="text-xs font-normal text-white">CP</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-1">{t.adminKpiCpNote}</div>
          </div>
        </InteractiveTilt>

        <InteractiveTilt maxTilt={4.0} scale={1.02} elevationZ={14}>
          <div className="bg-[#0b1016] border border-[#16222f] hover:border-[#00d9b5]/40 rounded-2xl p-5 h-full transition-colors shadow-md">
            <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
              <span>{t.adminKpiQueue}</span>
              <Clock className="w-4 h-4 text-[#00d9b5]" />
            </div>
            <div className="text-2xl font-black text-white">
              {language === 'fa' ? `${pendingOrdersCount.toLocaleString('fa-IR')} سفارش` : `${pendingOrdersCount} Queue`}
            </div>
            <div className="text-[10px] text-cyan-400 mt-1">{t.adminKpiQueueNote}</div>
          </div>
        </InteractiveTilt>

        <InteractiveTilt maxTilt={4.0} scale={1.02} elevationZ={14}>
          <div className="bg-[#0b1016] border border-[#16222f] hover:border-[#00d9b5]/40 rounded-2xl p-5 h-full transition-colors shadow-md">
            <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
              <span>{t.adminKpiDb}</span>
              <Database className="w-4 h-4 text-[#00d9b5]" />
            </div>
            <div className="text-2xl font-black text-white font-mono">
              SSL VERIFIED
            </div>
            <div className="text-[10px] text-[#00d9b5] mt-1 font-mono">{t.adminKpiDbNote}</div>
          </div>
        </InteractiveTilt>
      </div>

      {/* Admin Tab Switcher */}
      <div className="flex items-center gap-2 border-b border-[#14202d] pb-3 mb-8 overflow-x-auto">
        <button
          onClick={() => setActiveTab('orders')}
          className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'orders'
              ? 'bg-[#00d9b5] text-[#06080b]'
              : 'text-slate-400 hover:text-white bg-[#0b1016]'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>{t.adminTabOrders} ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('catalog')}
          className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'catalog'
              ? 'bg-[#00d9b5] text-[#06080b]'
              : 'text-slate-400 hover:text-white bg-[#0b1016]'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>{t.adminTabCatalog} ({packages.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('postgres')}
          className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'postgres'
              ? 'bg-[#00d9b5] text-[#06080b]'
              : 'text-slate-400 hover:text-white bg-[#0b1016]'
          }`}
        >
          <Database className="w-4 h-4" />
          <span>{t.adminTabPostgres}</span>
        </button>

        <button
          onClick={() => setActiveTab('users')}
          className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'users'
              ? 'bg-[#00d9b5] text-[#06080b]'
              : 'text-slate-400 hover:text-white bg-[#0b1016]'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>{t.adminTabUsers}</span>
        </button>
      </div>

      {/* TAB 1: ORDERS MANAGEMENT */}
      {activeTab === 'orders' && (
        <div className="bg-[#0b1016] border border-[#16222f] rounded-2xl p-6 shadow-md">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#00d9b5]" />
              <span>{t.adminTabOrders}</span>
            </h2>

            <div className="flex gap-1.5 overflow-x-auto pb-1">
              {['all', 'processing', 'delivered', 'pending', 'cancelled'].map((st) => (
                <button
                  key={st}
                  onClick={() => setOrderFilter(st)}
                  className={`px-3 py-1 text-xs rounded-lg border whitespace-nowrap ${
                    orderFilter === st
                      ? 'bg-[#00d9b5] text-[#06080b] font-bold border-[#00d9b5]'
                      : 'bg-[#070b0f] border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {st === 'all' 
                    ? (language === 'fa' ? 'همه سفارش‌ها' : 'All') 
                    : st === 'processing' 
                    ? (language === 'fa' ? 'در حال شارژ' : 'Processing') 
                    : st === 'delivered' 
                    ? (language === 'fa' ? 'تکمیل شده' : 'Delivered') 
                    : st === 'pending' 
                    ? (language === 'fa' ? 'در انتظار' : 'Pending') 
                    : (language === 'fa' ? 'لغو شده' : 'Cancelled')}
                </button>
              ))}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className={`w-full text-xs ${language === 'fa' ? 'text-right' : 'text-left'}`}>
              <thead>
                <tr className="border-b border-[#152332] text-slate-400 pb-2">
                  <th className="py-3 px-3">{t.adminOrderTableCode}</th>
                  <th className="py-3 px-3">{t.adminOrderTableUser}</th>
                  <th className="py-3 px-3">{t.adminOrderTablePkg}</th>
                  <th className="py-3 px-3">{t.adminOrderTableUid}</th>
                  <th className="py-3 px-3">{t.adminOrderTableAmount}</th>
                  <th className="py-3 px-3">{t.adminOrderTableStatus}</th>
                  <th className={`py-3 px-3 ${language === 'fa' ? 'text-left' : 'text-right'}`}>{t.adminOrderTableActions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#131e2b]">
                {filteredOrders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-[#0e1622] transition-colors">
                    <td className="py-3.5 px-3 font-mono font-bold text-[#00d9b5]">{ord.orderCode}</td>
                    <td className="py-3.5 px-3 text-slate-200 font-medium">{ord.userName}</td>
                    <td className="py-3.5 px-3 text-white">
                      <div>{ord.packageName}</div>
                      <div className="text-[10px] text-slate-500 font-num">{ord.cpAmount} CP</div>
                    </td>
                    <td className="py-3.5 px-3 font-mono text-slate-300">
                      <div>{ord.playerUid}</div>
                      <div className="text-[10px] text-slate-500">{ord.region}</div>
                    </td>
                    <td className="py-3.5 px-3 font-num font-bold text-white">
                      {formatPrice(ord.priceToman)}
                    </td>
                    <td className="py-3.5 px-3">
                      <span className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                        ord.status === 'delivered'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          : ord.status === 'processing'
                          ? 'bg-[#00d9b5]/15 text-[#00d9b5] border border-[#00d9b5]/30'
                          : 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/30'
                      }`}>
                        {ord.status === 'delivered' 
                          ? (language === 'fa' ? 'تکمیل شده' : 'Delivered') 
                          : ord.status === 'processing' 
                          ? (language === 'fa' ? 'در حال شارژ' : 'Processing') 
                          : (language === 'fa' ? 'در صف' : 'Pending')}
                      </span>
                    </td>
                    <td className={`py-3.5 px-3 ${language === 'fa' ? 'text-left' : 'text-right'}`}>
                      <div className={`flex items-center gap-1.5 ${language === 'fa' ? 'justify-end' : 'justify-start'}`}>
                        {ord.status !== 'delivered' && (
                          <button
                            onClick={() => updateOrderStatus(ord.id, 'delivered')}
                            className="px-2.5 py-1 bg-[#00d9b5] hover:bg-[#00c49f] text-[#06080b] font-bold rounded text-[11px] transition-colors flex items-center gap-1 shadow-sm"
                            title={t.adminConfirmDispatch}
                          >
                            <CheckCircle className="w-3 h-3" />
                            <span>{t.adminConfirmDispatch}</span>
                          </button>
                        )}
                        {ord.status !== 'processing' && (
                          <button
                            onClick={() => updateOrderStatus(ord.id, 'processing')}
                            className="px-2 py-1 bg-[#121c27] hover:bg-[#182635] text-slate-300 rounded text-[11px] border border-slate-700"
                          >
                            {t.adminSetProcessing}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: CATALOG MANAGEMENT */}
      {activeTab === 'catalog' && (
        <div className="bg-[#0b1016] border border-[#16222f] rounded-2xl p-6 shadow-md">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Package className="w-5 h-5 text-[#00d9b5]" />
                <span>{t.adminTabCatalog}</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                {language === 'fa' 
                  ? 'تغییر قیمت، مدیریت موجودی، فعال‌سازی تخفیف و افزودن بسته‌های جدید.'
                  : 'Manage pricing, stock state, discounts and new bundle creations.'}
              </p>
            </div>

            <button
              onClick={() => setShowAddPackageModal(true)}
              className="px-4 py-2 bg-[#00d9b5] hover:bg-[#00c49f] text-[#06080b] font-bold text-xs rounded-xl shadow-sm flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>{t.adminAddPkgBtn}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {packages.map((pkg) => (
              <InteractiveTilt key={pkg.id} maxTilt={4.5} scale={1.025} elevationZ={16}>
                <div className="bg-[#080d13] border border-[#162534] hover:border-[#00d9b5]/40 rounded-xl p-4 flex flex-col justify-between h-full transition-colors">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-mono font-bold text-[#00d9b5]">
                        {pkg.cpAmount} + {pkg.bonusCp} CP
                      </span>
                      <button
                        onClick={() => updatePackage(pkg.id, { inStock: !pkg.inStock })}
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          pkg.inStock
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : 'bg-red-500/10 text-red-400 border border-red-500/30'
                        }`}
                      >
                        {pkg.inStock 
                          ? (language === 'fa' ? 'موجود' : 'In Stock') 
                          : (language === 'fa' ? 'ناموجود' : 'Out of Stock')}
                      </button>
                    </div>

                    <h3 className="text-sm font-bold text-white mb-1">
                      {language === 'fa' ? pkg.title : `${pkg.cpAmount} CP Bundle`}
                    </h3>
                    <p className="text-xs text-slate-400 mb-3 line-clamp-2">
                      {language === 'fa' ? pkg.description : 'Authentic Activision CP points deposit.'}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-[#131d29] flex items-center justify-between">
                    <div className="text-xs font-num font-bold text-white">
                      {formatPrice(pkg.priceToman)}
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => {
                          const newPrice = Math.round(pkg.priceToman * 0.95);
                          updatePackage(pkg.id, { priceToman: newPrice });
                          showToast(
                            language === 'fa' 
                              ? `قیمت پکیج ۵٪ کاهش یافت و به ${newPrice.toLocaleString('fa-IR')} تومان تغییر یافت.` 
                              : `Price discounted 5% to ${formatPrice(newPrice)}.`
                          );
                        }}
                        className="px-2 py-1 bg-[#101924] hover:bg-[#162332] text-slate-300 rounded border border-slate-700 text-[11px]"
                        title={language === 'fa' ? 'اعمال تخفیف ۵ درصدی سریع' : 'Apply 5% Quick Discount'}
                      >
                        {language === 'fa' ? 'تخفیف ۵٪' : '-5% Off'}
                      </button>
                      <button
                        onClick={() => deletePackage(pkg.id)}
                        className="p-1.5 bg-[#101924] hover:bg-red-950/40 text-red-400 rounded border border-slate-700"
                        title={language === 'fa' ? 'حذف پکیج' : 'Delete Package'}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </InteractiveTilt>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: POSTGRESQL DATABASE & SECURITY CONSOLE */}
      {activeTab === 'postgres' && (
        <div className="space-y-6">
          <div className="bg-[#0b1016] border border-[#16222f] rounded-2xl p-6 shadow-md">
            <div className="flex items-center justify-between pb-4 border-b border-[#14202d] mb-6">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Database className="w-5 h-5 text-[#00d9b5]" />
                  <span>{t.adminTabPostgres}</span>
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  {language === 'fa'
                    ? 'پیکربندی سطح سازمانی با رمزنگاری داده‌های حساس، اتصال SSL و پیشگیری از SQL Injection.'
                    : 'Enterprise-grade architecture with AES-256-GCM data encryption, TLS 1.3, and prepared statement defense.'}
                </p>
              </div>

              <div className="flex items-center gap-2 font-mono text-xs text-[#00d9b5]">
                <ShieldCheck className="w-4 h-4" />
                <span>SSL MODE: VERIFY-FULL</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <InteractiveTilt maxTilt={3.8} scale={1.018} elevationZ={12}>
                <div className="bg-[#070b0f] border border-[#141f2b] p-4 rounded-xl h-full">
                  <div className="text-xs text-slate-400 mb-1 flex items-center justify-between">
                    <span>{t.adminDbEngine}</span>
                    <Server className="w-3.5 h-3.5 text-[#00d9b5]" />
                  </div>
                  <div className="text-base font-bold text-white font-mono">PostgreSQL 16.2</div>
                  <div className="text-[10px] text-[#00d9b5] mt-1 font-mono">PgBouncer Pool: 10/10 Active</div>
                </div>
              </InteractiveTilt>

              <InteractiveTilt maxTilt={3.8} scale={1.018} elevationZ={12}>
                <div className="bg-[#070b0f] border border-[#141f2b] p-4 rounded-xl h-full">
                  <div className="text-xs text-slate-400 mb-1 flex items-center justify-between">
                    <span>{t.adminDbCrypto}</span>
                    <Lock className="w-3.5 h-3.5 text-[#00d9b5]" />
                  </div>
                  <div className="text-base font-bold text-white font-mono">AES-256-GCM + SHA512</div>
                  <div className="text-[10px] text-emerald-400 mt-1 font-mono">Zero-Knowledge UID Storage</div>
                </div>
              </InteractiveTilt>

              <InteractiveTilt maxTilt={3.8} scale={1.018} elevationZ={12}>
                <div className="bg-[#070b0f] border border-[#141f2b] p-4 rounded-xl h-full">
                  <div className="text-xs text-slate-400 mb-1 flex items-center justify-between">
                    <span>{t.adminDbLatency}</span>
                    <Activity className="w-3.5 h-3.5 text-[#00d9b5]" />
                  </div>
                  <div className="text-base font-bold text-white font-mono">1.18 ms</div>
                  <div className="text-[10px] text-[#00d9b5] mt-1 font-mono">Prepared Statements: 100%</div>
                </div>
              </InteractiveTilt>
            </div>

            {/* Interactive Query Simulator for Admin verification */}
            <div className="bg-[#070b0f] border border-[#172534] rounded-xl p-4 mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono font-bold text-[#00d9b5] flex items-center gap-1.5">
                  <Terminal className="w-4 h-4" />
                  <span>{t.adminDbRunnerTitle}</span>
                </span>
                <span className="text-[10px] text-slate-500 font-mono">INJECTION SHIELD: ENABLED</span>
              </div>

              <form onSubmit={handleExecuteSafeSql} className="flex gap-2">
                <input
                  type="text"
                  value={sqlTestQuery}
                  onChange={(e) => setSqlTestQuery(e.target.value)}
                  className="flex-1 bg-[#05080c] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-[#00d9b5] focus:outline-none"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#00d9b5] text-[#06080b] font-bold text-xs rounded-lg shadow-sm"
                >
                  {t.adminDbRunnerBtn}
                </button>
              </form>

              {sqlTestResult && (
                <div className="mt-3 p-2.5 bg-[#040608] rounded-lg border border-slate-800 text-[11px] font-mono text-emerald-400">
                  {sqlTestResult}
                </div>
              )}
            </div>

            {/* Live Security Audit Log from DB */}
            <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#00d9b5]" />
              <span>{t.adminDbAuditTitle}</span>
            </h3>

            <div className="divide-y divide-[#131e2b] bg-[#070b0f] rounded-xl border border-[#141f2b] p-3 text-xs font-mono">
              {auditLogs.map((log) => (
                <div key={log.id} className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <span className="text-[#00d9b5] font-bold">{log.action}</span>
                    <div className="text-[10px] text-slate-500 mt-0.5">
                      {language === 'fa' 
                        ? `جدول: ${log.table} · رمزنگاری: ${log.encryption} · کلاینت: ${log.ip}`
                        : `Table: ${log.table} · Crypto: ${log.encryption} · Client: ${log.ip}`}
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-[10px] text-slate-400 font-num">{log.latencyMs}ms</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#00d9b5]/15 text-[#00d9b5] border border-[#00d9b5]/30">
                      {log.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: USERS MANAGEMENT */}
      {activeTab === 'users' && (
        <div className="bg-[#0b1016] border border-[#16222f] rounded-2xl p-6 shadow-md">
          <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <Users className="w-5 h-5 text-[#00d9b5]" />
            <span>{t.adminTabUsers}</span>
          </h2>

          <InteractiveTilt maxTilt={3.8} scale={1.018} elevationZ={12}>
            <div className="bg-[#080d13] border border-[#162534] hover:border-[#00d9b5]/40 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-colors">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-base font-bold text-white">{user.name}</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#00d9b5]/15 text-[#00d9b5] border border-[#00d9b5]/30">
                    {user.role === 'admin' ? (language === 'fa' ? 'مدیر سیستم' : 'System Admin') : 'Operator'}
                  </span>
                </div>
                <div className="text-xs text-slate-400 font-num">
                  {language === 'fa' ? `ایمیل: ${user.email} · همراه: ${user.phone}` : `Email: ${user.email} · Phone: ${user.phone}`}
                </div>
                <div className="text-xs font-mono text-slate-300">
                  UID: {user.playerUid} · {t.ucpActivisionTag} {user.activisionId}
                </div>
              </div>

              <div>
                <div className="text-xs text-slate-400">{t.walletBalance}:</div>
                <div className="text-base font-extrabold text-[#00d9b5] font-num">
                  {formatPrice(user.walletBalance)}
                </div>
              </div>
            </div>
          </InteractiveTilt>
        </div>
      )}

      {/* Add Package Modal */}
      {showAddPackageModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" data-scroll-lock="true">
          <div className={`w-full max-w-md bg-[#0b1016] border border-[#1e2e3e] rounded-2xl p-6 shadow-2xl ${
            language === 'fa' ? 'text-right' : 'text-left'
          }`}>
            <h2 className="text-lg font-bold text-white mb-4">
              {language === 'fa' ? 'افزودن پکیج جدید سی‌پی به فروشگاه' : 'Add New CP Bundle to Store'}
            </h2>

            <form onSubmit={handleCreatePackage} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-200 mb-1">
                  {language === 'fa' ? 'عنوان پکیج:' : 'Bundle Title:'}
                </label>
                <input
                  type="text"
                  required
                  value={pkgTitle}
                  onChange={(e) => setPkgTitle(e.target.value)}
                  placeholder={language === 'fa' ? 'مثال: ۱۲۰۰ سی‌پی کالاف موبایل' : 'e.g. 1,200 CP Points'}
                  className="w-full bg-[#080d13] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-200 mb-1">
                    {language === 'fa' ? 'تعداد سی‌پی خالص:' : 'Net CP Points:'}
                  </label>
                  <input
                    type="number"
                    required
                    value={pkgCp}
                    onChange={(e) => setPkgCp(Number(e.target.value))}
                    className="w-full bg-[#080d13] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-num"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-200 mb-1">
                    {language === 'fa' ? 'سی‌پی هدیه (بونوس):' : 'Free Bonus CP:'}
                  </label>
                  <input
                    type="number"
                    value={pkgBonus}
                    onChange={(e) => setPkgBonus(Number(e.target.value))}
                    className="w-full bg-[#080d13] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-num"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-200 mb-1">
                  {language === 'fa' ? 'قیمت به تومان:' : 'Price (Toman):'}
                </label>
                <input
                  type="number"
                  required
                  value={pkgPrice}
                  onChange={(e) => setPkgPrice(Number(e.target.value))}
                  className="w-full bg-[#080d13] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none font-num"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-200 mb-1">
                    {language === 'fa' ? 'پلتفرم:' : 'Game Platform:'}
                  </label>
                  <select
                    value={pkgGameType}
                    onChange={(e) => setPkgGameType(e.target.value as GameType)}
                    className="w-full bg-[#080d13] border border-slate-800 text-xs text-white rounded-xl px-3 py-2 focus:outline-none"
                  >
                    <option value="codm">{language === 'fa' ? 'کالاف دیوتی موبایل' : 'COD Mobile'}</option>
                    <option value="warzone">{language === 'fa' ? 'وارزون (PC/Console)' : 'Warzone'}</option>
                    <option value="both">{language === 'fa' ? 'مشترک هر دو' : 'Both'}</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-200 mb-1">
                    {language === 'fa' ? 'روش تحویل:' : 'Delivery Method:'}
                  </label>
                  <select
                    value={pkgDeliveryType}
                    onChange={(e) => setPkgDeliveryType(e.target.value as DeliveryType)}
                    className="w-full bg-[#080d13] border border-slate-800 text-xs text-white rounded-xl px-3 py-2 focus:outline-none"
                  >
                    <option value="uid_only">{language === 'fa' ? 'فقط با آیدی عددی (UID)' : 'Player UID Only'}</option>
                    <option value="activision_login">{language === 'fa' ? 'با اکانت اکتیویژن' : 'Activision Login'}</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#00d9b5] hover:bg-[#00c49f] text-[#06080b] font-bold text-xs rounded-xl"
                >
                  {language === 'fa' ? 'ثبت پکیج در کاتالوگ' : 'Add Package'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddPackageModal(false)}
                  className="px-4 py-2.5 bg-[#121c27] text-slate-300 text-xs rounded-xl"
                >
                  {t.ticketCancel}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
