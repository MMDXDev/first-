import React, { useEffect, useState, useRef } from 'react';

export const DynamicWarzoneBackground: React.FC = () => {
  const [mousePos, setMousePos] = useState({ x: 0.5, y: 0.5 });
  const [hudStats, setHudStats] = useState({ gridX: 452.4, gridY: 188.7, azimuth: 284 });
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const normX = e.clientX / window.innerWidth;
      const normY = e.clientY / window.innerHeight;
      setMousePos({ x: normX, y: normY });

      // Update tactical HUD numbers based on mouse
      setHudStats({
        gridX: parseFloat((400 + normX * 120).toFixed(1)),
        gridY: parseFloat((150 + normY * 85).toFixed(1)),
        azimuth: Math.round(normX * 360),
      });
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Ambient tactical particles / subtle embers on canvas (No harsh neon glow)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    const particleCount = 25;
    const particles = Array.from({ length: particleCount }).map(() => ({
      x: Math.random() * width,
      y: Math.random() * height,
      size: Math.random() * 1.5 + 0.5,
      speedY: Math.random() * -0.4 - 0.15,
      speedX: (Math.random() - 0.5) * 0.3,
      opacity: Math.random() * 0.4 + 0.1,
      pulse: Math.random() * Math.PI,
    }));

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      particles.forEach((p) => {
        p.y += p.speedY;
        p.x += p.speedX;
        p.pulse += 0.02;
        const currentOpacity = p.opacity * (0.6 + 0.4 * Math.sin(p.pulse));

        if (p.y < -10) {
          p.y = height + 10;
          p.x = Math.random() * width;
        }
        if (p.x < -10) p.x = width + 10;
        if (p.x > width + 10) p.x = -10;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(0, 217, 181, ${currentOpacity})`;
        // No neon shadow blur
        ctx.shadowBlur = 0;
        ctx.fill();
      });

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  // Subtle parallax translations
  const bgShiftX = (mousePos.x - 0.5) * -22;
  const bgShiftY = (mousePos.y - 0.5) * -14;

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden select-none bg-[#05070a]">
      {/* Dynamic Warzone Parallax Background Image */}
      <div
        className="absolute -inset-8 bg-cover bg-center transition-transform duration-300 ease-out opacity-20"
        style={{
          backgroundImage: `url('/src/assets/images/warzone_bg_tactical_1792428987026.jpg')`,
          transform: `translate3d(${bgShiftX}px, ${bgShiftY}px, 0) scale(1.04)`,
          filter: 'brightness(0.65) contrast(1.2) grayscale(0.2)',
        }}
      />

      {/* Deep Obsidian Gradient Scrim */}
      <div 
        className="absolute inset-0"
        style={{
          background: 'radial-gradient(circle at center, rgba(5,7,10,0.5) 0%, rgba(5,7,10,0.92) 75%, #05070a 100%)',
        }}
      />

      {/* Gentle, non-neon ambient vignette */}
      <div
        className="absolute w-[500px] h-[500px] rounded-full pointer-events-none transition-transform duration-300 ease-out opacity-10 blur-3xl"
        style={{
          background: 'radial-gradient(circle, rgba(0, 217, 181, 0.25) 0%, transparent 65%)',
          left: `${mousePos.x * 100}%`,
          top: `${mousePos.y * 100}%`,
          transform: 'translate(-50%, -50%)',
        }}
      />

      {/* Subtle Canvas Particle Sparks */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full opacity-40" />

      {/* Tactical Grid Overlay */}
      <div className="absolute inset-0 tactical-grid opacity-20" />

      {/* Tactical HUD Corner Telemetry (Clean, unboxed) */}
      <div className="absolute top-20 left-6 text-[10px] font-mono tracking-wider text-slate-500 hidden md:block select-none leading-relaxed">
        <div>SECTOR // VERDANSK TACTICAL GRID</div>
        <div>POS: {hudStats.gridX}N / {hudStats.gridY}E</div>
        <div>AZIMUTH: {hudStats.azimuth}° | TACTICAL SECURE</div>
      </div>

      <div className="absolute bottom-8 right-8 text-[10px] font-mono tracking-wider text-slate-500 hidden md:block select-none text-right leading-relaxed">
        <div>POSTGRESQL 16 VERIFY-FULL</div>
        <div>ENCRYPTION: AES-256-GCM / SHA-512</div>
        <div>DATA LAYER: SECURE</div>
      </div>

      {/* Subtle Tactical Scanline Lines */}
      <div className="absolute inset-0 tactical-scanlines opacity-30 pointer-events-none" />
    </div>
  );
};
