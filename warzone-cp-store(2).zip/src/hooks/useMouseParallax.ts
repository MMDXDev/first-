import { useState, useEffect } from 'react';

/**
 * Hook to provide subtle, gentle parallax coordinates based on mouse position.
 * Clamped and damped to ensure smooth micro-motion across all sections.
 */
export function useMouseParallax(intensity = 3) {
  const [offset, setOffset] = useState({ x: 0, y: 0, normX: 0.5, normY: 0.5 });

  useEffect(() => {
    let animId: number;
    let targetX = 0;
    let targetY = 0;
    let currentX = 0;
    let currentY = 0;

    const handleMouseMove = (e: MouseEvent) => {
      const { innerWidth, innerHeight } = window;
      const normX = e.clientX / innerWidth;
      const normY = e.clientY / innerHeight;

      // Gentle micro-offset
      targetX = (normX - 0.5) * intensity;
      targetY = (normY - 0.5) * intensity;
    };

    // Smooth lerp loop for buttery stability (no jitter)
    const update = () => {
      currentX += (targetX - currentX) * 0.12;
      currentY += (targetY - currentY) * 0.12;
      setOffset({
        x: parseFloat(currentX.toFixed(2)),
        y: parseFloat(currentY.toFixed(2)),
        normX: 0.5 + currentX / (intensity * 2 || 1),
        normY: 0.5 + currentY / (intensity * 2 || 1),
      });
      animId = requestAnimationFrame(update);
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    animId = requestAnimationFrame(update);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animId);
    };
  }, [intensity]);

  return offset;
}
