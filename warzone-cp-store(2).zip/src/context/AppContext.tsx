import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  CPPackage, 
  Order, 
  Ticket, 
  UserProfile, 
  SavedAccount, 
  SecurityAuditLog, 
  OrderStatus, 
  TicketStatus,
  TicketDepartment,
  TicketPriority
} from '../types/index.ts';
import { 
  INITIAL_PACKAGES, 
  INITIAL_ORDERS, 
  INITIAL_TICKETS, 
  INITIAL_USER, 
  INITIAL_SAVED_ACCOUNTS,
  SECURITY_AUDIT_LOGS 
} from '../data/mockData.ts';
import { TRANSLATIONS, Language } from '../data/translations.ts';

interface AppContextType {
  packages: CPPackage[];
  orders: Order[];
  tickets: Ticket[];
  user: UserProfile;
  savedAccounts: SavedAccount[];
  auditLogs: SecurityAuditLog[];
  activeTab: 'home' | 'store' | 'tickets' | 'ucp' | 'admin';
  setActiveTab: (tab: 'home' | 'store' | 'tickets' | 'ucp' | 'admin') => void;
  selectedPackageForBuy: CPPackage | null;
  setSelectedPackageForBuy: (pkg: CPPackage | null) => void;
  heavySmoothScroll: boolean;
  setHeavySmoothScroll: (enabled: boolean) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof TRANSLATIONS['fa'];
  notifications: { id: string; text: string; type: 'success' | 'info' | 'warn' }[];
  showToast: (text: string, type?: 'success' | 'info' | 'warn') => void;
  createOrder: (pkg: CPPackage, uid: string, region: string, tag?: string, activisionEmail?: string, notes?: string) => Order;
  updateOrderStatus: (orderId: string, status: OrderStatus) => void;
  createTicket: (subject: string, department: TicketDepartment, priority: TicketPriority, message: string, orderCodeRef?: string) => Ticket;
  addTicketMessage: (ticketId: string, message: string, isAdmin?: boolean) => void;
  updateTicketStatus: (ticketId: string, status: TicketStatus) => void;
  addPackage: (pkg: Omit<CPPackage, 'id'>) => void;
  updatePackage: (id: string, updates: Partial<CPPackage>) => void;
  deletePackage: (id: string) => void;
  depositWallet: (amount: number) => void;
  addSavedAccount: (acc: Omit<SavedAccount, 'id'>) => void;
  deleteSavedAccount: (id: string) => void;
  toggleTwoFactor: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEY_PACKAGES = 'cod_cp_packages_v1';
const STORAGE_KEY_ORDERS = 'cod_cp_orders_v1';
const STORAGE_KEY_TICKETS = 'cod_cp_tickets_v1';
const STORAGE_KEY_USER = 'cod_cp_user_v1';
const STORAGE_KEY_ACCOUNTS = 'cod_cp_accounts_v1';
const STORAGE_KEY_LANG = 'cod_cp_lang_v1';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_LANG);
    return (saved === 'en' || saved === 'fa') ? saved : 'fa';
  });

  const [packages, setPackages] = useState<CPPackage[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PACKAGES);
    return saved ? JSON.parse(saved) : INITIAL_PACKAGES;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_ORDERS);
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  const [tickets, setTickets] = useState<Ticket[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_TICKETS);
    return saved ? JSON.parse(saved) : INITIAL_TICKETS;
  });

  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_USER);
    return saved ? JSON.parse(saved) : INITIAL_USER;
  });

  const [savedAccounts, setSavedAccounts] = useState<SavedAccount[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_ACCOUNTS);
    return saved ? JSON.parse(saved) : INITIAL_SAVED_ACCOUNTS;
  });

  const [auditLogs, setAuditLogs] = useState<SecurityAuditLog[]>(SECURITY_AUDIT_LOGS);
  const [activeTab, setActiveTab] = useState<'home' | 'store' | 'tickets' | 'ucp' | 'admin'>('home');
  const [selectedPackageForBuy, setSelectedPackageForBuy] = useState<CPPackage | null>(null);
  const [heavySmoothScroll, setHeavySmoothScroll] = useState<boolean>(true);
  const [notifications, setNotifications] = useState<{ id: string; text: string; type: 'success' | 'info' | 'warn' }[]>([]);

  const t = TRANSLATIONS[language];

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem(STORAGE_KEY_LANG, lang);
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
  };

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'fa' ? 'rtl' : 'ltr';
  }, [language]);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PACKAGES, JSON.stringify(packages));
  }, [packages]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_ORDERS, JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_TICKETS, JSON.stringify(tickets));
  }, [tickets]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_ACCOUNTS, JSON.stringify(savedAccounts));
  }, [savedAccounts]);

  const showToast = (text: string, type: 'success' | 'info' | 'warn' = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setNotifications(prev => [...prev, { id, text, type }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 4500);
  };

  const createOrder = (
    pkg: CPPackage, 
    uid: string, 
    region: string, 
    tag?: string, 
    activisionEmail?: string,
    notes?: string
  ): Order => {
    const randomCode = 'CP-' + Math.floor(10000 + Math.random() * 90000);
    const newOrder: Order = {
      id: 'ord-' + Date.now(),
      orderCode: randomCode,
      userId: user.id,
      userName: user.name,
      packageId: pkg.id,
      packageName: pkg.title,
      cpAmount: pkg.cpAmount + pkg.bonusCp,
      priceToman: pkg.priceToman,
      gameType: pkg.gameType,
      deliveryType: pkg.deliveryType,
      playerUid: uid,
      playerTag: tag || user.activisionId,
      activisionEmail: activisionEmail,
      region: region,
      status: 'processing',
      createdAt: language === 'fa' 
        ? 'هم اکنون (' + new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }) + ')'
        : 'Just now (' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) + ')',
      deliverySpeedMinutes: 3,
      notes: notes || (language === 'fa' ? 'تراکنش ایمن در دیتابیس ثبت و به صف واریز ارسال گردید' : 'Transaction safely recorded in database and sent to dispatch queue'),
    };

    setOrders(prev => [newOrder, ...prev]);
    setUser(prev => ({
      ...prev,
      totalOrders: prev.totalOrders + 1,
    }));

    // Log to PostgreSQL security log
    const log: SecurityAuditLog = {
      id: 'sec-' + Date.now().toString().slice(-4),
      action: `INSERT INTO orders (code, uid, cp, price) VALUES ('${randomCode}', '***', ${pkg.cpAmount}, ${pkg.priceToman})`,
      table: 'orders',
      latencyMs: 1.4,
      ip: 'Encrypted Gateway Node #1',
      encryption: 'AES-256-GCM / SHA-512 Hash',
      status: 'ENCRYPTED',
      timestamp: language === 'fa' ? 'هم اکنون' : 'Just now',
    };
    setAuditLogs(prev => [log, ...prev.slice(0, 15)]);

    const toastMsg = language === 'fa'
      ? `سفارش ${randomCode} با موفقیت ثبت شد! در حال انتقال به صف واریز...`
      : `Order ${randomCode} placed successfully! Dispatching to queue...`;
    showToast(toastMsg, 'success');
    return newOrder;
  };

  const updateOrderStatus = (orderId: string, status: OrderStatus) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
    const statusLabel = status === 'delivered' 
      ? (language === 'fa' ? 'تکمیل شده' : 'Delivered') 
      : status === 'processing' 
      ? (language === 'fa' ? 'در حال انجام' : 'Processing') 
      : (language === 'fa' ? 'لغو شده' : 'Cancelled');
    showToast(language === 'fa' ? `وضعیت سفارش به "${statusLabel}" تغییر کرد.` : `Order status updated to "${statusLabel}".`);
  };

  const createTicket = (
    subject: string, 
    department: TicketDepartment, 
    priority: TicketPriority, 
    message: string, 
    orderCodeRef?: string
  ): Ticket => {
    const randomTicketNumber = 'TCK-' + Math.floor(1000 + Math.random() * 9000);
    const newTicket: Ticket = {
      id: 'tck-' + Date.now(),
      ticketNumber: randomTicketNumber,
      userId: user.id,
      userName: user.name,
      department,
      priority,
      status: 'open',
      subject,
      orderCodeRef,
      createdAt: (language === 'fa' ? 'امروز - ' : 'Today - ') + new Date().toLocaleTimeString(language === 'fa' ? 'fa-IR' : 'en-US', { hour: '2-digit', minute: '2-digit' }),
      updatedAt: (language === 'fa' ? 'امروز - ' : 'Today - ') + new Date().toLocaleTimeString(language === 'fa' ? 'fa-IR' : 'en-US', { hour: '2-digit', minute: '2-digit' }),
      messages: [
        {
          id: 'msg-' + Date.now(),
          sender: 'user',
          senderName: user.name,
          message,
          timestamp: new Date().toLocaleTimeString(language === 'fa' ? 'fa-IR' : 'en-US', { hour: '2-digit', minute: '2-digit' }),
          isStaff: false,
        }
      ]
    };

    setTickets(prev => [newTicket, ...prev]);
    showToast(language === 'fa' ? `تیکت جدید با شماره ${randomTicketNumber} با موفقیت ایجاد شد!` : `Support ticket ${randomTicketNumber} created successfully!`, 'success');
    return newTicket;
  };

  const addTicketMessage = (ticketId: string, message: string, isAdmin = false) => {
    const time = new Date().toLocaleTimeString(language === 'fa' ? 'fa-IR' : 'en-US', { hour: '2-digit', minute: '2-digit' });
    setTickets(prev => prev.map(t => {
      if (t.id === ticketId) {
        return {
          ...t,
          status: isAdmin ? 'answered' : 'in_progress',
          updatedAt: (language === 'fa' ? 'امروز - ' : 'Today - ') + time,
          messages: [
            ...t.messages,
            {
              id: 'msg-' + Date.now(),
              sender: isAdmin ? 'admin' : 'user',
              senderName: isAdmin ? (language === 'fa' ? 'پشتیبانی سینیور کالاف سنتر' : 'CALAF Center Senior Staff') : user.name,
              message,
              timestamp: time,
              isStaff: isAdmin,
            }
          ]
        };
      }
      return t;
    }));
    showToast(isAdmin 
      ? (language === 'fa' ? 'پاسخ پشتیبانی ارسال گردید.' : 'Staff response dispatched.') 
      : (language === 'fa' ? 'پیام شما به تیکت اضافه شد.' : 'Message added to ticket thread.'));
  };

  const updateTicketStatus = (ticketId: string, status: TicketStatus) => {
    setTickets(prev => prev.map(t => t.id === ticketId ? { ...t, status } : t));
    showToast(language === 'fa' ? 'وضعیت تیکت بروزرسانی شد.' : 'Ticket status updated.');
  };

  const addPackage = (pkg: Omit<CPPackage, 'id'>) => {
    const newPkg: CPPackage = {
      ...pkg,
      id: 'pkg-' + Date.now(),
    };
    setPackages(prev => [newPkg, ...prev]);
    showToast(language === 'fa' ? 'پکیج جدید سی‌پی به فروشگاه اضافه شد.' : 'New CP package added to catalog.');
  };

  const updatePackage = (id: string, updates: Partial<CPPackage>) => {
    setPackages(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
    showToast(language === 'fa' ? 'اطلاعات پکیج با موفقیت ذخیره گردید.' : 'Package updated successfully.');
  };

  const deletePackage = (id: string) => {
    setPackages(prev => prev.filter(p => p.id !== id));
    showToast(language === 'fa' ? 'پکیج حذف گردید.' : 'Package deleted.', 'info');
  };

  const depositWallet = (amount: number) => {
    setUser(prev => ({
      ...prev,
      walletBalance: prev.walletBalance + amount,
    }));
    showToast(language === 'fa' 
      ? `کیف پول شما به مبلغ ${amount.toLocaleString('fa-IR')} تومان شارژ شد.`
      : `Wallet credited with ${amount.toLocaleString('en-US')} Toman.`, 'success');
  };

  const addSavedAccount = (acc: Omit<SavedAccount, 'id'>) => {
    const newAcc: SavedAccount = {
      ...acc,
      id: 'acc-' + Date.now(),
    };
    setSavedAccounts(prev => [...prev, newAcc]);
    showToast(language === 'fa' ? 'اکانت بازی با موفقیت ذخیره شد.' : 'Gaming account saved successfully.');
  };

  const deleteSavedAccount = (id: string) => {
    setSavedAccounts(prev => prev.filter(a => a.id !== id));
    showToast(language === 'fa' ? 'اکانت بازی حذف گردید.' : 'Gaming account deleted.', 'info');
  };

  const toggleTwoFactor = () => {
    setUser(prev => ({
      ...prev,
      twoFactorEnabled: !prev.twoFactorEnabled,
    }));
    showToast(!user.twoFactorEnabled 
      ? (language === 'fa' ? 'تایید هویت دو مرحله‌ای (2FA) فعال گردید.' : 'Two-Factor Authentication (2FA) activated.')
      : (language === 'fa' ? 'تایید هویت دو مرحله‌ای غیرفعال شد.' : 'Two-Factor Authentication disabled.'), 'info');
  };

  return (
    <AppContext.Provider
      value={{
        packages,
        orders,
        tickets,
        user,
        savedAccounts,
        auditLogs,
        activeTab,
        setActiveTab,
        selectedPackageForBuy,
        setSelectedPackageForBuy,
        heavySmoothScroll,
        setHeavySmoothScroll,
        language,
        setLanguage,
        t,
        notifications,
        showToast,
        createOrder,
        updateOrderStatus,
        createTicket,
        addTicketMessage,
        updateTicketStatus,
        addPackage,
        updatePackage,
        deletePackage,
        depositWallet,
        addSavedAccount,
        deleteSavedAccount,
        toggleTwoFactor,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
