import React from 'react';
import { AppProvider, useApp } from './context/AppContext.tsx';
import { CustomCursor } from './components/CustomCursor.tsx';
import { DynamicWarzoneBackground } from './components/DynamicWarzoneBackground.tsx';
import { HeavySmoothScroll } from './components/HeavySmoothScroll.tsx';
import { Navbar } from './components/Navbar.tsx';
import { HomeView } from './components/HomeView.tsx';
import { StoreView } from './components/StoreView.tsx';
import { TicketSystemView } from './components/TicketSystemView.tsx';
import { UCPView } from './components/UCPView.tsx';
import { AdminPanelView } from './components/AdminPanelView.tsx';
import { PurchaseModal } from './components/PurchaseModal.tsx';
import { ToastContainer } from './components/ToastContainer.tsx';

const AppContent: React.FC = () => {
  const { activeTab, selectedPackageForBuy, setSelectedPackageForBuy } = useApp();

  return (
    <div className="min-h-screen bg-[#05070a] text-slate-100 font-sans relative selection:bg-[#00f5d4]/20 selection:text-[#00f5d4]">
      {/* Warzone Dynamic Mouse-Reactive Tactical Background */}
      <DynamicWarzoneBackground />

      {/* Bug-free Custom Tactical Crosshair Cursor */}
      <CustomCursor />

      {/* Real-time Toasts & Notifications */}
      <ToastContainer />

      {/* Top Navbar */}
      <Navbar />

      {/* Heavy Smooth Scroll Wrapper with Momentum lerp */}
      <HeavySmoothScroll>
        <main className="w-full relative z-10">
          {activeTab === 'home' && <HomeView />}
          {activeTab === 'store' && <StoreView />}
          {activeTab === 'tickets' && <TicketSystemView />}
          {activeTab === 'ucp' && <UCPView />}
          {activeTab === 'admin' && <AdminPanelView />}
        </main>
      </HeavySmoothScroll>

      {/* Quick Buy Modal when a package is chosen */}
      {selectedPackageForBuy && <PurchaseModal />}
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
